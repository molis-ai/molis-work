import { z } from "zod";
export declare const backgroundProfileSchema: z.ZodObject<{
    experience: z.ZodString;
    opinions: z.ZodString;
    value: z.ZodString;
    curiosity: z.ZodString;
    ai: z.ZodString;
    style: z.ZodString;
    publishing: z.ZodString;
}, z.core.$strict>;
export declare const interviewKeys: readonly ["experience", "audience", "value", "voice", "opinions", "curiosity", "ai", "style", "publishing", "boundaries"];
export declare const interviewKeySchema: z.ZodEnum<{
    value: "value";
    experience: "experience";
    opinions: "opinions";
    curiosity: "curiosity";
    ai: "ai";
    style: "style";
    publishing: "publishing";
    audience: "audience";
    voice: "voice";
    boundaries: "boundaries";
}>;
export declare const interviewScopeSchema: z.ZodObject<{
    userId: z.ZodString;
    accountId: z.ZodNullable<z.ZodString>;
}, z.core.$strict>;
export declare const backgroundInterviewSchema: z.ZodObject<{
    id: z.ZodString;
    scope: z.ZodObject<{
        userId: z.ZodString;
        accountId: z.ZodNullable<z.ZodString>;
    }, z.core.$strict>;
    revision: z.ZodNumber;
    backgroundId: z.ZodString;
    name: z.ZodString;
    answers: z.ZodRecord<z.ZodEnum<{
        value: "value";
        experience: "experience";
        opinions: "opinions";
        curiosity: "curiosity";
        ai: "ai";
        style: "style";
        publishing: "publishing";
        audience: "audience";
        voice: "voice";
        boundaries: "boundaries";
    }>, z.ZodString>;
    skipped: z.ZodArray<z.ZodEnum<{
        value: "value";
        experience: "experience";
        opinions: "opinions";
        curiosity: "curiosity";
        ai: "ai";
        style: "style";
        publishing: "publishing";
        audience: "audience";
        voice: "voice";
        boundaries: "boundaries";
    }>>;
    expectedHash: z.ZodString;
    savedAt: z.ZodNullable<z.ZodString>;
    updatedAt: z.ZodString;
    lastSave: z.ZodOptional<z.ZodObject<{
        revision: z.ZodNumber;
        hash: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type BackgroundInterview = z.infer<typeof backgroundInterviewSchema>;
