import type { AgentRunView, AgentRunUsage } from "@molis-ai/molis-work-contracts/services/agent-host";
import { type ModelExecution } from "../../src/domain/creation-model-receipt.ts";
type Observation = Pick<AgentRunView, "ref" | "phase"> & {
    frozen?: Pick<AgentRunView["frozen"], "model_id">;
    usage?: AgentRunUsage;
    started_at?: string;
    ended_at?: string | null;
    stop_reason?: string;
};
export declare function projectWorkRun(view: Observation, selection: {
    provider_id: string;
    model_id: string;
}, observedAt?: string): ModelExecution;
export {};
