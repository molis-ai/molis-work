import { z } from "zod";
import { type Creation, type Output } from "./creation.ts";
export declare const artifactKeySchema: z.ZodEnum<{
    MANUSCRIPT: "MANUSCRIPT";
    XIAOHONGSHU: "XIAOHONGSHU";
    WECHAT: "WECHAT";
    JIKE: "JIKE";
    ZHIHU: "ZHIHU";
    X: "X";
    DOUYIN_ARTICLE: "DOUYIN_ARTICLE";
    REDDIT: "REDDIT";
}>;
export type ArtifactKey = z.infer<typeof artifactKeySchema>;
export declare const artifactKeys: ("MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT")[];
export declare const editionKeys: ("XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT")[];
export declare const platforms: {
    readonly MANUSCRIPT: {
        readonly label: "内容底稿";
        readonly carrier: "MANUSCRIPT";
    };
    readonly XIAOHONGSHU: {
        readonly label: "小红书图文";
        readonly carrier: "TEXT_CAROUSEL";
    };
    readonly WECHAT: {
        readonly label: "公众号文章";
        readonly carrier: "ARTICLE";
    };
    readonly JIKE: {
        readonly label: "即刻文字";
        readonly carrier: "POST";
    };
    readonly ZHIHU: {
        readonly label: "知乎回答";
        readonly carrier: "ARTICLE";
    };
    readonly X: {
        readonly label: "X 中文帖";
        readonly carrier: "POST";
    };
    readonly DOUYIN_ARTICLE: {
        readonly label: "抖音长文章";
        readonly carrier: "ARTICLE";
    };
    readonly REDDIT: {
        readonly label: "Reddit 英文帖";
        readonly carrier: "POST";
    };
};
export declare const manuscriptSnapshotSchema: z.ZodObject<{
    hash: z.ZodString;
    at: z.ZodString;
    plan: z.ZodObject<{
        title: z.ZodString;
        core: z.ZodString;
        outline: z.ZodString;
        evidence: z.ZodString;
        boundaries: z.ZodString;
    }, z.core.$strict>;
    output: z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
        cards: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ManuscriptSnapshot = z.infer<typeof manuscriptSnapshotSchema>;
export declare const artifactStateSchema: z.ZodObject<{
    working: z.ZodNullable<z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
        cards: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    workingBaseId: z.ZodNullable<z.ZodString>;
    workingVersionId: z.ZodNullable<z.ZodString>;
    workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
        GENERATED: "GENERATED";
        AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
        AUTHOR_RESTORED: "AUTHOR_RESTORED";
        AUTHOR_MANUAL: "AUTHOR_MANUAL";
    }>>>;
    target: z.ZodObject<{
        platform: z.ZodString;
        carrier: z.ZodString;
        account: z.ZodString;
    }, z.core.$strict>;
    basis: z.ZodOptional<z.ZodObject<{
        hash: z.ZodString;
        at: z.ZodString;
        plan: z.ZodObject<{
            title: z.ZodString;
            core: z.ZodString;
            outline: z.ZodString;
            evidence: z.ZodString;
            boundaries: z.ZodString;
        }, z.core.$strict>;
        output: z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ArtifactState = z.infer<typeof artifactStateSchema>;
export declare function emptyArtifact(key: ArtifactKey): ArtifactState;
export declare function blankArtifacts(): Record<ArtifactKey, ArtifactState>;
export declare const artifactsSchema: z.ZodPreprocess<z.ZodObject<{
    MANUSCRIPT: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    XIAOHONGSHU: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    WECHAT: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    JIKE: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    ZHIHU: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    X: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    DOUYIN_ARTICLE: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    REDDIT: z.ZodObject<{
        working: z.ZodNullable<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
            cards: z.ZodArray<z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
        workingBaseId: z.ZodNullable<z.ZodString>;
        workingVersionId: z.ZodNullable<z.ZodString>;
        workingOrigin: z.ZodOptional<z.ZodNullable<z.ZodEnum<{
            GENERATED: "GENERATED";
            AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
            AUTHOR_RESTORED: "AUTHOR_RESTORED";
            AUTHOR_MANUAL: "AUTHOR_MANUAL";
        }>>>;
        target: z.ZodObject<{
            platform: z.ZodString;
            carrier: z.ZodString;
            account: z.ZodString;
        }, z.core.$strict>;
        basis: z.ZodOptional<z.ZodObject<{
            hash: z.ZodString;
            at: z.ZodString;
            plan: z.ZodObject<{
                title: z.ZodString;
                core: z.ZodString;
                outline: z.ZodString;
                evidence: z.ZodString;
                boundaries: z.ZodString;
            }, z.core.$strict>;
            output: z.ZodObject<{
                title: z.ZodString;
                body: z.ZodString;
                cards: z.ZodArray<z.ZodObject<{
                    title: z.ZodString;
                    body: z.ZodString;
                }, z.core.$strict>>;
            }, z.core.$strict>;
        }, z.core.$strict>>;
    }, z.core.$strict>;
}, z.core.$strict>>;
export declare function ensureArtifacts(doc: Creation): Record<"MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT", {
    working: {
        title: string;
        body: string;
        cards: {
            title: string;
            body: string;
        }[];
    } | null;
    workingBaseId: string | null;
    workingVersionId: string | null;
    target: {
        platform: string;
        carrier: string;
        account: string;
    };
    workingOrigin?: "GENERATED" | "AUTHOR_ADOPTED" | "AUTHOR_RESTORED" | "AUTHOR_MANUAL" | null | undefined;
    basis?: {
        hash: string;
        at: string;
        plan: {
            title: string;
            core: string;
            outline: string;
            evidence: string;
            boundaries: string;
        };
        output: {
            title: string;
            body: string;
            cards: {
                title: string;
                body: string;
            }[];
        };
    } | undefined;
}>;
export declare function artifactView(doc: Creation, key?: ArtifactKey): Creation;
export declare function commitArtifact(doc: Creation, key: ArtifactKey | undefined, view: Creation): void;
export declare function manuscriptSnapshot(doc: Creation): ManuscriptSnapshot;
export declare function validateArtifactOutput(key: ArtifactKey, output: Output): void;
