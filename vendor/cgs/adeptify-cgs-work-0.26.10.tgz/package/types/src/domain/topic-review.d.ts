import { z } from "zod";
export declare const valuePathSchema: z.ZodEnum<{
    TIMELY: "TIMELY";
    PRACTICAL: "PRACTICAL";
    PERSPECTIVE: "PERSPECTIVE";
    MECHANISM: "MECHANISM";
    DEBATE: "DEBATE";
    CASE: "CASE";
}>;
export declare const topicSupportSchema: z.ZodObject<{
    sourceId: z.ZodString;
    quote: z.ZodString;
    claim: z.ZodString;
    kind: z.ZodEnum<{
        OBSERVATION: "OBSERVATION";
        AUTHOR_REPORT: "AUTHOR_REPORT";
        RESEARCH_INTERPRETATION: "RESEARCH_INTERPRETATION";
    }>;
}, z.core.$strict>;
export declare const topicAssessmentSchema: z.ZodObject<{
    repository: z.ZodOptional<z.ZodObject<{
        owner: z.ZodString;
        repo: z.ZodString;
    }, z.core.$strict>>;
    roundId: z.ZodString;
    methodVersion: z.ZodString;
    verdict: z.ZodEnum<{
        PASS: "PASS";
        ADJUST: "ADJUST";
    }>;
    valuePaths: z.ZodArray<z.ZodEnum<{
        TIMELY: "TIMELY";
        PRACTICAL: "PRACTICAL";
        PERSPECTIVE: "PERSPECTIVE";
        MECHANISM: "MECHANISM";
        DEBATE: "DEBATE";
        CASE: "CASE";
    }>>;
    rationale: z.ZodString;
    reader: z.ZodString;
    timing: z.ZodString;
    support: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        quote: z.ZodString;
        claim: z.ZodString;
        kind: z.ZodEnum<{
            OBSERVATION: "OBSERVATION";
            AUTHOR_REPORT: "AUTHOR_REPORT";
            RESEARCH_INTERPRETATION: "RESEARCH_INTERPRETATION";
        }>;
    }, z.core.$strict>>;
    findingIds: z.ZodArray<z.ZodString>;
    packages: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        packageId: z.ZodString;
        manifestHash: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const publicPropositionSchema: z.ZodObject<{
    key: z.ZodString;
    title: z.ZodString;
    angle: z.ZodString;
    reason: z.ZodString;
    reader: z.ZodString;
    readerValue: z.ZodString;
    timing: z.ZodString;
    valuePaths: z.ZodArray<z.ZodEnum<{
        TIMELY: "TIMELY";
        PRACTICAL: "PRACTICAL";
        PERSPECTIVE: "PERSPECTIVE";
        MECHANISM: "MECHANISM";
        DEBATE: "DEBATE";
        CASE: "CASE";
    }>>;
    findingIds: z.ZodArray<z.ZodString>;
    support: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        quote: z.ZodString;
        claim: z.ZodString;
        kind: z.ZodEnum<{
            OBSERVATION: "OBSERVATION";
            AUTHOR_REPORT: "AUTHOR_REPORT";
            RESEARCH_INTERPRETATION: "RESEARCH_INTERPRETATION";
        }>;
    }, z.core.$strict>>;
    suggestions: z.ZodArray<z.ZodString>;
    unknowns: z.ZodArray<z.ZodString>;
}, z.core.$strict>;
export declare const publicGenerationSchema: z.ZodObject<{
    candidates: z.ZodArray<z.ZodObject<{
        key: z.ZodString;
        title: z.ZodString;
        angle: z.ZodString;
        reason: z.ZodString;
        reader: z.ZodString;
        readerValue: z.ZodString;
        timing: z.ZodString;
        valuePaths: z.ZodArray<z.ZodEnum<{
            TIMELY: "TIMELY";
            PRACTICAL: "PRACTICAL";
            PERSPECTIVE: "PERSPECTIVE";
            MECHANISM: "MECHANISM";
            DEBATE: "DEBATE";
            CASE: "CASE";
        }>>;
        findingIds: z.ZodArray<z.ZodString>;
        support: z.ZodArray<z.ZodObject<{
            sourceId: z.ZodString;
            quote: z.ZodString;
            claim: z.ZodString;
            kind: z.ZodEnum<{
                OBSERVATION: "OBSERVATION";
                AUTHOR_REPORT: "AUTHOR_REPORT";
                RESEARCH_INTERPRETATION: "RESEARCH_INTERPRETATION";
            }>;
        }, z.core.$strict>>;
        suggestions: z.ZodArray<z.ZodString>;
        unknowns: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    notUsed: z.ZodArray<z.ZodObject<{
        findingId: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const researchNeedSchema: z.ZodObject<{
    question: z.ZodString;
    impact: z.ZodString;
    evidenceNeeded: z.ZodArray<z.ZodString>;
    stopWhen: z.ZodString;
}, z.core.$strict>;
export declare const publicReviewSchema: z.ZodObject<{
    reviews: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        verdict: z.ZodLiteral<"PASS">;
        adjusted: z.ZodNull;
        researchNeed: z.ZodNull;
        key: z.ZodString;
        rationale: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        verdict: z.ZodLiteral<"ADJUST">;
        adjusted: z.ZodObject<{
            key: z.ZodString;
            title: z.ZodString;
            angle: z.ZodString;
            reason: z.ZodString;
            reader: z.ZodString;
            readerValue: z.ZodString;
            timing: z.ZodString;
            valuePaths: z.ZodArray<z.ZodEnum<{
                TIMELY: "TIMELY";
                PRACTICAL: "PRACTICAL";
                PERSPECTIVE: "PERSPECTIVE";
                MECHANISM: "MECHANISM";
                DEBATE: "DEBATE";
                CASE: "CASE";
            }>>;
            findingIds: z.ZodArray<z.ZodString>;
            support: z.ZodArray<z.ZodObject<{
                sourceId: z.ZodString;
                quote: z.ZodString;
                claim: z.ZodString;
                kind: z.ZodEnum<{
                    OBSERVATION: "OBSERVATION";
                    AUTHOR_REPORT: "AUTHOR_REPORT";
                    RESEARCH_INTERPRETATION: "RESEARCH_INTERPRETATION";
                }>;
            }, z.core.$strict>>;
            suggestions: z.ZodArray<z.ZodString>;
            unknowns: z.ZodArray<z.ZodString>;
        }, z.core.$strict>;
        researchNeed: z.ZodNull;
        key: z.ZodString;
        rationale: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        verdict: z.ZodLiteral<"RESEARCH">;
        adjusted: z.ZodNull;
        researchNeed: z.ZodObject<{
            question: z.ZodString;
            impact: z.ZodString;
            evidenceNeeded: z.ZodArray<z.ZodString>;
            stopWhen: z.ZodString;
        }, z.core.$strict>;
        key: z.ZodString;
        rationale: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        verdict: z.ZodLiteral<"REJECT">;
        adjusted: z.ZodNull;
        researchNeed: z.ZodNull;
        key: z.ZodString;
        rationale: z.ZodString;
    }, z.core.$strict>], "verdict">>;
}, z.core.$strict>;
export type PublicProposition = z.infer<typeof publicPropositionSchema>;
export type PublicReview = z.infer<typeof publicReviewSchema>["reviews"][number];
