# `@prologue/sdk`

要嵌入消费 App 的那一份 TypeScript 引擎。创建 Runtime、开会话、调模型、跑 Agent 和工具，都从这里进。

它规定合同和状态机，但不自己保管 API Key、不自己发 HTTP、不自己读写磁盘。这些交给原生 Host。App 只走包根公开入口，不 deep import。

## 现役模块

模块清单和各自职责见 [`src/README.md`](./src/README.md)。功能定义在 [`docs/product/requirements/`](../../docs/product/requirements/)，本包不复述。

现役树只包含已经做过的模块。需要新模块时由带来它的队列项新建，不预建空壳。

## 不做什么

不提供产品 UI。不拥有消费 App 的项目、任务和按钮状态。不在 JavaScript 里保存或读回 API Key。

## 验证

```bash
pnpm exec tsc -p tsconfig.typecheck.json --noEmit && pnpm exec vitest run packages/sdk/test
```

真实证据走 `test/*.live.test.ts`，需要仓库根 `.env.local` 里的 Key。缺 Key 时跳过，**跳过不算完成证据**。

下一项做什么看 [`docs/slices/requirement-order.md`](../../docs/slices/requirement-order.md)。
