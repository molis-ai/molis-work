import { z } from "zod";
import { type ResearchBrief } from "../domain/research-contract.ts";
import type { ResearchRunStore } from "../storage/research-run-store.ts";
declare const sourceManifestSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<"ResearchSourceManifestV1">;
    manifestId: z.ZodString;
    rssFeeds: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        feedUrl: z.ZodURL;
        questionRefs: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    authorizedMaterials: z.ZodArray<z.ZodObject<{
        materialId: z.ZodString;
        authorizationRef: z.ZodString;
        authorizationScope: z.ZodOptional<z.ZodEnum<{
            PUBLIC_SOURCE: "PUBLIC_SOURCE";
            TEAM_FACT: "TEAM_FACT";
        }>>;
        url: z.ZodURL;
        title: z.ZodString;
        excerpt: z.ZodString;
        capturedAt: z.ZodString;
        publishedAt: z.ZodOptional<z.ZodString>;
        sourceFamilyRef: z.ZodString;
        questionRefs: z.ZodArray<z.ZodString>;
    }, z.core.$strict>>;
    aiKolSnapshotRef: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type ResearchSourceManifest = z.infer<typeof sourceManifestSchema>;
export interface ResearchAcquisitionTask {
    readonly taskId: string;
    readonly operationId: string;
    readonly sourceKind: "PUBLIC_SEARCH" | "RSS";
    readonly evidenceRole: "PRIMARY" | "COUNTEREVIDENCE" | "CONTEXT";
    readonly questionRefs: readonly string[];
    readonly query: string;
    readonly feedUrl?: string;
    readonly limit: number;
    readonly since?: string;
    readonly deadlineMs: number;
}
export interface AcquiredMaterial {
    readonly materialId: string;
    readonly url: string;
    readonly title: string;
    readonly excerpt: string;
    readonly capturedAt: string;
    readonly publishedAt?: string;
    readonly sourceFamilyRef?: string;
    readonly contentHash?: `sha256:${string}`;
}
export interface AcquisitionReceipt {
    readonly taskId: string;
    readonly status: "SUCCEEDED" | "FAILED" | "CANCELLED";
    readonly attemptedAt: string;
    readonly completedAt: string;
    readonly provider: string;
    readonly errorCode?: string;
    readonly retryable?: boolean;
    readonly warnings?: readonly string[];
    readonly usage?: Readonly<{
        providerCalls: number;
        fetchExtractCalls: number;
        bytes: number;
    }>;
    readonly materials: readonly AcquiredMaterial[];
}
export interface EvidenceAcquisitionPort {
    execute(task: ResearchAcquisitionTask): Promise<AcquisitionReceipt>;
}
export interface ResearchMaterial extends AcquiredMaterial {
    readonly canonicalUrl: string;
    readonly sourceKind: "PUBLIC_SEARCH" | "RSS" | "AUTHORIZED_MATERIAL";
    readonly sourceFamilyRef: string;
    readonly evidenceRoles: readonly ResearchAcquisitionTask["evidenceRole"][];
    readonly questionRefs: readonly string[];
    readonly sourceTaskRefs: readonly string[];
    readonly authorizationRef?: string;
    readonly authorizationScope?: "PUBLIC_SOURCE" | "TEAM_FACT";
}
export interface CoverageGap {
    readonly gapId: string;
    readonly questionId?: string;
    readonly kind: "SOURCE_FAILED" | "BUDGET_EXHAUSTED" | "MINIMUM_MATERIALS_MISSING" | "INDEPENDENT_SOURCES_MISSING" | "COUNTEREVIDENCE_UNCLASSIFIED" | "AI_KOL_INPUT_PENDING";
    readonly severity: "BLOCKING" | "MATERIAL";
    readonly detail: string;
    readonly retryable: boolean;
}
export interface EvidenceResearchRun {
    readonly schemaVersion: "EvidenceResearchRunV1";
    readonly researchRunId: string;
    readonly inputFingerprint: `sha256:${string}`;
    readonly briefRef: string;
    readonly entryMode: ResearchBrief["entryMode"];
    readonly primaryObjective: ResearchBrief["primaryObjective"];
    readonly manifestRef: string;
    readonly state: "EXECUTING" | "COMPLETED" | "PARTIAL" | "INSUFFICIENT" | "CANCELLED";
    readonly stopReason: "IN_PROGRESS" | "REQUIREMENTS_MET" | "PARTIAL_COVERAGE" | "EVIDENCE_INSUFFICIENT" | "BUDGET_EXHAUSTED" | "USER_CANCELLED";
    readonly startedAt: string;
    readonly completedAt: string;
    readonly queries: readonly Readonly<{
        taskId: string;
        questionRefs: readonly string[];
        sourceKind: "PUBLIC_SEARCH" | "RSS";
        evidenceRole: ResearchAcquisitionTask["evidenceRole"];
        query: string;
        feedUrl?: string;
    }>[];
    readonly receipts: readonly AcquisitionReceipt[];
    readonly materials: readonly ResearchMaterial[];
    readonly evidenceMap: Readonly<{
        targets: readonly Readonly<{
            questionId: string;
            dimension: string;
            materialRefs: readonly string[];
            independentSourceFamilyCount: number;
            coverage: "COVERED" | "PARTIAL" | "MISSING";
        }>[];
    }>;
    readonly coverageGaps: readonly CoverageGap[];
    readonly budget: Readonly<{
        maxProviderCalls: number;
        usedProviderCalls: number;
        maxFetchExtractCalls: number;
        usedFetchExtractCalls: number;
        maxMaterials: number;
        retainedMaterials: number;
        maxBytes: number;
        retainedBytes: number;
    }>;
}
export declare function executeEvidenceResearchRun(input: {
    readonly researchRunId: string;
    readonly brief: unknown;
    readonly contract: unknown;
    readonly sourceManifest: unknown;
    readonly acquisition: EvidenceAcquisitionPort;
    readonly store: ResearchRunStore;
    readonly now?: () => string;
}): Promise<EvidenceResearchRun>;
export {};
