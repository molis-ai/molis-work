import { z } from "zod";
/** A bounded observation from the trusted model port, not an execution owner
 * or proof that the candidate passed CGS validation or author review. */
export declare const modelExecutionSchema: z.ZodObject<{
    runtime: z.ZodLiteral<"molis-work">;
    runRef: z.ZodObject<{
        runId: z.ZodString;
        sessionId: z.ZodString;
    }, z.core.$strict>;
    configuredModel: z.ZodObject<{
        providerId: z.ZodString;
        modelId: z.ZodString;
    }, z.core.$strict>;
    phase: z.ZodString;
    observedAt: z.ZodString;
    startedAt: z.ZodNullable<z.ZodString>;
    endedAt: z.ZodNullable<z.ZodString>;
    stopReason: z.ZodOptional<z.ZodString>;
    usage: z.ZodObject<{
        input: z.ZodObject<{
            value: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodEnum<{
                unknown: "unknown";
                partial: "partial";
                reported: "reported";
                estimated: "estimated";
                "partial-estimated": "partial-estimated";
            }>;
        }, z.core.$strict>;
        output: z.ZodObject<{
            value: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodEnum<{
                unknown: "unknown";
                partial: "partial";
                reported: "reported";
                estimated: "estimated";
                "partial-estimated": "partial-estimated";
            }>;
        }, z.core.$strict>;
        cachedInput: z.ZodObject<{
            value: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodEnum<{
                unknown: "unknown";
                partial: "partial";
                reported: "reported";
                estimated: "estimated";
                "partial-estimated": "partial-estimated";
            }>;
        }, z.core.$strict>;
        cacheCreation: z.ZodObject<{
            value: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodEnum<{
                unknown: "unknown";
                partial: "partial";
                reported: "reported";
                estimated: "estimated";
                "partial-estimated": "partial-estimated";
            }>;
        }, z.core.$strict>;
        costUsd: z.ZodObject<{
            value: z.ZodNullable<z.ZodNumber>;
            coverage: z.ZodEnum<{
                unknown: "unknown";
                partial: "partial";
                reported: "reported";
                estimated: "estimated";
                "partial-estimated": "partial-estimated";
            }>;
        }, z.core.$strict>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ModelExecution = z.infer<typeof modelExecutionSchema>;
