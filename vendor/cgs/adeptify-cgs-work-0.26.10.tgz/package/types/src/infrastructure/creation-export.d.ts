import type { Version } from "../domain/creation.ts";
export declare function renderCreationPng(svg: string): Buffer;
export declare function makeCreationDownload(version: Version, approvedAt: string, account: string): Promise<Buffer>;
export declare function makePlatformBundle(bundles: {
    version: Version;
    approval: {
        at: string;
    };
    target: {
        account: string;
    };
}[]): Promise<Buffer>;
