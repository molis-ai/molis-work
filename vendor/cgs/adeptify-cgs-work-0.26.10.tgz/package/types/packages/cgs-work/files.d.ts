/** Native file work belongs to the trusted package loader; the archived plugin factory holds no binary loader or worker path. */
export interface CgsWorkFiles {
    renderPng: typeof import('../../src/infrastructure/creation-export.ts').renderCreationPng;
    download: typeof import('../../src/infrastructure/creation-export.ts').makeCreationDownload;
    platformBundle: typeof import('../../src/infrastructure/creation-export.ts').makePlatformBundle;
    originalPreview: typeof import('../../src/infrastructure/creation-original-preview.ts').makeOriginalPreview;
}
