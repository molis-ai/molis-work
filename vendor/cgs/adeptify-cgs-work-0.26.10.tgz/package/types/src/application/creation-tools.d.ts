import { z } from "zod";
import { type DiscussionResult, type GenerationResult, type Operation, type Output, type PlanResult } from "../domain/creation.ts";
import type { ModelTool } from "../infrastructure/creation-provider.ts";
import { emptyPreferences } from "../../web/creation-preferences.js";
export declare const metadataSchema: z.ZodObject<{
    researchNeed: z.ZodOptional<z.ZodObject<{
        question: z.ZodString;
        impact: z.ZodString;
        evidenceNeeded: z.ZodArray<z.ZodString>;
        stopWhen: z.ZodString;
        query: z.ZodString;
    }, z.core.$strict>>;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    preferenceChange: z.ZodOptional<z.ZodObject<{
        quote: z.ZodString;
        changes: z.ZodArray<z.ZodObject<{
            field: z.ZodEnum<{
                voice: "voice";
                boundaries: "boundaries";
            }>;
            before: z.ZodNullable<z.ZodString>;
            after: z.ZodNullable<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function parseNativeSave(provider: string, kind: Operation["kind"], args: unknown, parseResult?: (raw: string, kind: Operation["kind"]) => PlanResult | GenerationResult): PlanResult | GenerationResult;
export declare function validateDraft(result: GenerationResult, current?: Output | null, operation?: Operation): void;
export type ToolSessionOptions = {
    provider: string;
    references: ReadonlyMap<string, unknown>;
    writingPreferences: {
        field: string;
        text: string;
    }[];
    produceGuide: string;
    layout: {
        aspectRatio: string;
        maxCards: number;
        maxCardTitleCharacters: number;
        maxCardBodyCharacters: number;
    };
    progress?: (message: string) => Promise<void>;
    parseResult?: (raw: string, kind: Operation["kind"]) => PlanResult | GenerationResult;
};
export declare class CreationToolSession {
    tools: ModelTool[];
    saveDraft: ModelTool;
    readOnly: boolean;
    explicit: boolean;
    productionLoaded: boolean;
    awaitingCandidate: boolean;
    closed: boolean;
    metadata: Pick<DiscussionResult, "nextSteps" | "preferenceChange" | "researchNeed">;
    candidate?: PlanResult | GenerationResult;
    operation: Operation;
    options: ToolSessionOptions;
    pendingPreferences: ReturnType<typeof emptyPreferences>;
    registered: ModelTool[];
    constructor(operation: Operation, options: ToolSessionOptions);
    close(): void;
    offered(): ModelTool[];
    nativeCatalog(): ModelTool[];
    allowedNames(): Set<string>;
    parseMetadata(raw: unknown): {
        researchNeed?: {
            question: string;
            impact: string;
            evidenceNeeded: string[];
            stopWhen: string;
            query: string;
        } | undefined;
        nextSteps?: {
            label: string;
            reason: string;
            prompt: string;
        }[] | undefined;
        preferenceChange?: {
            quote: string;
            changes: {
                field: "voice" | "boundaries";
                before: string | null;
                after: string | null;
            }[];
        } | undefined;
    };
    acceptMetadata(requested: z.infer<typeof metadataSchema>): void;
    invoke(name: string, args: unknown, savingCount?: number): Promise<unknown>;
    finishDiscussion(message: string): DiscussionResult;
    finishCandidate(): PlanResult | GenerationResult;
}
