import type { CreationStore } from "../storage/creation-store.ts";
export declare class BackgroundInterviews {
    private store;
    constructor(store: CreationStore);
    read(scope: unknown): Promise<{
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    } | {
        externalChanged: boolean;
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    } | null>;
    start(scope: unknown, input: unknown): Promise<{
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    }>;
    update(scope: unknown, input: unknown): Promise<{
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    }>;
    confirm(scope: unknown, input: unknown): Promise<{
        draft: {
            id: string;
            scope: {
                userId: string;
                accountId: string | null;
            };
            revision: number;
            backgroundId: string;
            name: string;
            answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
            skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
            expectedHash: string;
            savedAt: string | null;
            updatedAt: string;
            lastSave?: {
                revision: number;
                hash: string;
            } | undefined;
        };
        account: {
            id: string;
            name: string;
            audience: string;
            voice: string;
            boundaries: string;
            profile?: {
                experience: string;
                opinions: string;
                value: string;
                curiosity: string;
                ai: string;
                style: string;
                publishing: string;
            } | undefined;
        };
    }>;
}
