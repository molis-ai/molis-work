export declare const FILTERED_PROVIDER_CONTROL_MESSAGE = "[FILTERED_PROVIDER_CONTROL_MESSAGE]";
export type MaterialRejectionReason = "provider_control_message" | "extraction_failure_placeholder";
export declare function sanitizeExtractedMarkdown(markdown: string): string;
export declare function classifyUnusableMaterial(markdown: string): MaterialRejectionReason | undefined;
