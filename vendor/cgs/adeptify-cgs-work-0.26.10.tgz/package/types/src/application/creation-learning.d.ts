import { type ArtifactKey } from "../domain/creation-artifacts.ts";
import { type Creation, type Method } from "../domain/creation.ts";
import type { CreationStore, CreationState } from "../storage/creation-store.ts";
import { type CreationModel } from "./creation-model.ts";
import type { CreationExecutionScope } from "./creation-execution.ts";
export declare function applyLearnedMethod(method: Method, state: CreationState, doc: Creation, artifact: ArtifactKey): Method;
export declare class CreationLearning {
    private store;
    private resolve;
    private jobs;
    constructor(store: CreationStore, resolve: (doc: Creation) => Promise<CreationModel>, jobs?: CreationExecutionScope["jobs"]);
    private jobKey;
    private controlled;
    list(workId: string): Promise<{
        feedbackToConfirm: {
            operationId: string;
            artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
            text: string;
            origin: string;
        }[];
        candidates: {
            foundationChanged: boolean | null;
            readyComparisonId: string | null;
            id: string;
            workId: string;
            accountId: string | null;
            artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
            status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
            createdAt: string;
            fingerprint: string;
            foundationHash: string;
            baselineHash: string;
            feedback: {
                id: string;
                text: string;
            }[];
            acceptedOutputHash: string;
            comparisons: {
                id: string;
                workId: string;
                inputHash: string;
                methodHash: string;
                instructionHash: string;
                status: "RUNNING" | "SUCCEEDED" | "FAILED";
                startedAt: string;
                requestHash?: string | undefined;
                finishedAt?: string | undefined;
                before?: {
                    message: string;
                    output: {
                        title: string;
                        body: string;
                        cards: {
                            title: string;
                            body: string;
                        }[];
                    };
                    review: string[];
                    sourceMap: string[];
                    conception?: {
                        title: string;
                        core: string;
                        outline: string;
                        evidence: string;
                        boundaries: string;
                    } | undefined;
                    check?: {
                        status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                        issues: {
                            location: string;
                            problem: string;
                            evidence: string;
                            suggestion: string;
                            needsAuthor: boolean;
                            quote?: string | undefined;
                        }[];
                        repaired: boolean;
                        reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                        diagnostic?: string | undefined;
                    } | undefined;
                    authorQuestions?: {
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        location: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[] | undefined;
                    editScope?: {
                        type: "ALL" | "TITLE" | "BODY" | "CARD";
                        cardIndex?: number | undefined;
                    } | undefined;
                    nextSteps?: {
                        label: string;
                        reason: string;
                        prompt: string;
                    }[] | undefined;
                    role?: "revision" | "proposal" | undefined;
                    importKind?: "MANUSCRIPT" | undefined;
                } | undefined;
                after?: {
                    message: string;
                    output: {
                        title: string;
                        body: string;
                        cards: {
                            title: string;
                            body: string;
                        }[];
                    };
                    review: string[];
                    sourceMap: string[];
                    conception?: {
                        title: string;
                        core: string;
                        outline: string;
                        evidence: string;
                        boundaries: string;
                    } | undefined;
                    check?: {
                        status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                        issues: {
                            location: string;
                            problem: string;
                            evidence: string;
                            suggestion: string;
                            needsAuthor: boolean;
                            quote?: string | undefined;
                        }[];
                        repaired: boolean;
                        reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                        diagnostic?: string | undefined;
                    } | undefined;
                    authorQuestions?: {
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        location: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[] | undefined;
                    editScope?: {
                        type: "ALL" | "TITLE" | "BODY" | "CARD";
                        cardIndex?: number | undefined;
                    } | undefined;
                    nextSteps?: {
                        label: string;
                        reason: string;
                        prompt: string;
                    }[] | undefined;
                    role?: "revision" | "proposal" | undefined;
                    importKind?: "MANUSCRIPT" | undefined;
                } | undefined;
                executions?: {
                    before?: {
                        runtime: "molis-work";
                        runRef: {
                            runId: string;
                            sessionId: string;
                        };
                        configuredModel: {
                            providerId: string;
                            modelId: string;
                        };
                        phase: string;
                        observedAt: string;
                        startedAt: string | null;
                        endedAt: string | null;
                        usage: {
                            input: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            output: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            cachedInput: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            cacheCreation: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            costUsd: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                        };
                        stopReason?: string | undefined;
                    } | undefined;
                    after?: {
                        runtime: "molis-work";
                        runRef: {
                            runId: string;
                            sessionId: string;
                        };
                        configuredModel: {
                            providerId: string;
                            modelId: string;
                        };
                        phase: string;
                        observedAt: string;
                        startedAt: string | null;
                        endedAt: string | null;
                        usage: {
                            input: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            output: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            cachedInput: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            cacheCreation: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                            costUsd: {
                                value: number | null;
                                coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                            };
                        };
                        stopReason?: string | undefined;
                    } | undefined;
                } | undefined;
                error?: string | undefined;
            }[];
            instruction?: string | undefined;
            rationale?: string | undefined;
            applicability?: string | undefined;
            evidence?: {
                operationId: string;
                quote: string;
            }[] | undefined;
            previousId?: string | null | undefined;
            error?: string | undefined;
        }[];
        activeId: string | null;
    }>;
    confirmFeedback(workId: string, raw: unknown): Promise<Creation>;
    recover(): Promise<void>;
    propose(workId: string, raw: unknown): Promise<{
        id: string;
        workId: string;
        accountId: string | null;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
        createdAt: string;
        fingerprint: string;
        foundationHash: string;
        baselineHash: string;
        feedback: {
            id: string;
            text: string;
        }[];
        acceptedOutputHash: string;
        comparisons: {
            id: string;
            workId: string;
            inputHash: string;
            methodHash: string;
            instructionHash: string;
            status: "RUNNING" | "SUCCEEDED" | "FAILED";
            startedAt: string;
            requestHash?: string | undefined;
            finishedAt?: string | undefined;
            before?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            after?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            executions?: {
                before?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
                after?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
            } | undefined;
            error?: string | undefined;
        }[];
        instruction?: string | undefined;
        rationale?: string | undefined;
        applicability?: string | undefined;
        evidence?: {
            operationId: string;
            quote: string;
        }[] | undefined;
        previousId?: string | null | undefined;
        error?: string | undefined;
    }>;
    /** Host calls stay active until the model and candidate write have settled. */
    proposeAndWait(workId: string, raw: unknown, control?: {
        signal?: AbortSignal;
    }): Promise<{
        id: string;
        workId: string;
        accountId: string | null;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
        createdAt: string;
        fingerprint: string;
        foundationHash: string;
        baselineHash: string;
        feedback: {
            id: string;
            text: string;
        }[];
        acceptedOutputHash: string;
        comparisons: {
            id: string;
            workId: string;
            inputHash: string;
            methodHash: string;
            instructionHash: string;
            status: "RUNNING" | "SUCCEEDED" | "FAILED";
            startedAt: string;
            requestHash?: string | undefined;
            finishedAt?: string | undefined;
            before?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            after?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            executions?: {
                before?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
                after?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
            } | undefined;
            error?: string | undefined;
        }[];
        instruction?: string | undefined;
        rationale?: string | undefined;
        applicability?: string | undefined;
        evidence?: {
            operationId: string;
            quote: string;
        }[] | undefined;
        previousId?: string | null | undefined;
        error?: string | undefined;
    }>;
    private proposal;
    private synthesize;
    edit(workId: string, raw: unknown): Promise<{
        id: string;
        workId: string;
        accountId: string | null;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
        createdAt: string;
        fingerprint: string;
        foundationHash: string;
        baselineHash: string;
        feedback: {
            id: string;
            text: string;
        }[];
        acceptedOutputHash: string;
        comparisons: {
            id: string;
            workId: string;
            inputHash: string;
            methodHash: string;
            instructionHash: string;
            status: "RUNNING" | "SUCCEEDED" | "FAILED";
            startedAt: string;
            requestHash?: string | undefined;
            finishedAt?: string | undefined;
            before?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            after?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            executions?: {
                before?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
                after?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
            } | undefined;
            error?: string | undefined;
        }[];
        instruction?: string | undefined;
        rationale?: string | undefined;
        applicability?: string | undefined;
        evidence?: {
            operationId: string;
            quote: string;
        }[] | undefined;
        previousId?: string | null | undefined;
        error?: string | undefined;
    }>;
    compare(workId: string, raw: unknown): Promise<{
        id: string;
        workId: string;
        inputHash: string;
        methodHash: string;
        instructionHash: string;
        status: "RUNNING" | "SUCCEEDED" | "FAILED";
        startedAt: string;
        requestHash?: string | undefined;
        finishedAt?: string | undefined;
        before?: {
            message: string;
            output: {
                title: string;
                body: string;
                cards: {
                    title: string;
                    body: string;
                }[];
            };
            review: string[];
            sourceMap: string[];
            conception?: {
                title: string;
                core: string;
                outline: string;
                evidence: string;
                boundaries: string;
            } | undefined;
            check?: {
                status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                issues: {
                    location: string;
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[];
                repaired: boolean;
                reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                diagnostic?: string | undefined;
            } | undefined;
            authorQuestions?: {
                problem: string;
                evidence: string;
                suggestion: string;
                location: string;
                needsAuthor: boolean;
                quote?: string | undefined;
            }[] | undefined;
            editScope?: {
                type: "ALL" | "TITLE" | "BODY" | "CARD";
                cardIndex?: number | undefined;
            } | undefined;
            nextSteps?: {
                label: string;
                reason: string;
                prompt: string;
            }[] | undefined;
            role?: "revision" | "proposal" | undefined;
            importKind?: "MANUSCRIPT" | undefined;
        } | undefined;
        after?: {
            message: string;
            output: {
                title: string;
                body: string;
                cards: {
                    title: string;
                    body: string;
                }[];
            };
            review: string[];
            sourceMap: string[];
            conception?: {
                title: string;
                core: string;
                outline: string;
                evidence: string;
                boundaries: string;
            } | undefined;
            check?: {
                status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                issues: {
                    location: string;
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[];
                repaired: boolean;
                reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                diagnostic?: string | undefined;
            } | undefined;
            authorQuestions?: {
                problem: string;
                evidence: string;
                suggestion: string;
                location: string;
                needsAuthor: boolean;
                quote?: string | undefined;
            }[] | undefined;
            editScope?: {
                type: "ALL" | "TITLE" | "BODY" | "CARD";
                cardIndex?: number | undefined;
            } | undefined;
            nextSteps?: {
                label: string;
                reason: string;
                prompt: string;
            }[] | undefined;
            role?: "revision" | "proposal" | undefined;
            importKind?: "MANUSCRIPT" | undefined;
        } | undefined;
        executions?: {
            before?: {
                runtime: "molis-work";
                runRef: {
                    runId: string;
                    sessionId: string;
                };
                configuredModel: {
                    providerId: string;
                    modelId: string;
                };
                phase: string;
                observedAt: string;
                startedAt: string | null;
                endedAt: string | null;
                usage: {
                    input: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    output: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cachedInput: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cacheCreation: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    costUsd: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                };
                stopReason?: string | undefined;
            } | undefined;
            after?: {
                runtime: "molis-work";
                runRef: {
                    runId: string;
                    sessionId: string;
                };
                configuredModel: {
                    providerId: string;
                    modelId: string;
                };
                phase: string;
                observedAt: string;
                startedAt: string | null;
                endedAt: string | null;
                usage: {
                    input: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    output: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cachedInput: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cacheCreation: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    costUsd: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                };
                stopReason?: string | undefined;
            } | undefined;
        } | undefined;
        error?: string | undefined;
    } | {
        id: string;
        workId: string;
        requestHash: string;
        inputHash: string;
        methodHash: string;
        instructionHash: string;
        status: "RUNNING";
        startedAt: string;
    }>;
    compareAndWait(workId: string, raw: unknown, control?: {
        signal?: AbortSignal;
    }): Promise<{
        id: string;
        workId: string;
        inputHash: string;
        methodHash: string;
        instructionHash: string;
        status: "RUNNING" | "SUCCEEDED" | "FAILED";
        startedAt: string;
        requestHash?: string | undefined;
        finishedAt?: string | undefined;
        before?: {
            message: string;
            output: {
                title: string;
                body: string;
                cards: {
                    title: string;
                    body: string;
                }[];
            };
            review: string[];
            sourceMap: string[];
            conception?: {
                title: string;
                core: string;
                outline: string;
                evidence: string;
                boundaries: string;
            } | undefined;
            check?: {
                status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                issues: {
                    location: string;
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[];
                repaired: boolean;
                reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                diagnostic?: string | undefined;
            } | undefined;
            authorQuestions?: {
                problem: string;
                evidence: string;
                suggestion: string;
                location: string;
                needsAuthor: boolean;
                quote?: string | undefined;
            }[] | undefined;
            editScope?: {
                type: "ALL" | "TITLE" | "BODY" | "CARD";
                cardIndex?: number | undefined;
            } | undefined;
            nextSteps?: {
                label: string;
                reason: string;
                prompt: string;
            }[] | undefined;
            role?: "revision" | "proposal" | undefined;
            importKind?: "MANUSCRIPT" | undefined;
        } | undefined;
        after?: {
            message: string;
            output: {
                title: string;
                body: string;
                cards: {
                    title: string;
                    body: string;
                }[];
            };
            review: string[];
            sourceMap: string[];
            conception?: {
                title: string;
                core: string;
                outline: string;
                evidence: string;
                boundaries: string;
            } | undefined;
            check?: {
                status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                issues: {
                    location: string;
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[];
                repaired: boolean;
                reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                diagnostic?: string | undefined;
            } | undefined;
            authorQuestions?: {
                problem: string;
                evidence: string;
                suggestion: string;
                location: string;
                needsAuthor: boolean;
                quote?: string | undefined;
            }[] | undefined;
            editScope?: {
                type: "ALL" | "TITLE" | "BODY" | "CARD";
                cardIndex?: number | undefined;
            } | undefined;
            nextSteps?: {
                label: string;
                reason: string;
                prompt: string;
            }[] | undefined;
            role?: "revision" | "proposal" | undefined;
            importKind?: "MANUSCRIPT" | undefined;
        } | undefined;
        executions?: {
            before?: {
                runtime: "molis-work";
                runRef: {
                    runId: string;
                    sessionId: string;
                };
                configuredModel: {
                    providerId: string;
                    modelId: string;
                };
                phase: string;
                observedAt: string;
                startedAt: string | null;
                endedAt: string | null;
                usage: {
                    input: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    output: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cachedInput: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cacheCreation: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    costUsd: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                };
                stopReason?: string | undefined;
            } | undefined;
            after?: {
                runtime: "molis-work";
                runRef: {
                    runId: string;
                    sessionId: string;
                };
                configuredModel: {
                    providerId: string;
                    modelId: string;
                };
                phase: string;
                observedAt: string;
                startedAt: string | null;
                endedAt: string | null;
                usage: {
                    input: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    output: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cachedInput: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    cacheCreation: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                    costUsd: {
                        value: number | null;
                        coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                    };
                };
                stopReason?: string | undefined;
            } | undefined;
        } | undefined;
        error?: string | undefined;
    } | {
        id: string;
        workId: string;
        requestHash: string;
        inputHash: string;
        methodHash: string;
        instructionHash: string;
        status: "RUNNING";
        startedAt: string;
    }>;
    private comparison;
    private runComparison;
    cancel(workId: string, raw: unknown): Promise<{
        id: string;
        workId: string;
        accountId: string | null;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
        createdAt: string;
        fingerprint: string;
        foundationHash: string;
        baselineHash: string;
        feedback: {
            id: string;
            text: string;
        }[];
        acceptedOutputHash: string;
        comparisons: {
            id: string;
            workId: string;
            inputHash: string;
            methodHash: string;
            instructionHash: string;
            status: "RUNNING" | "SUCCEEDED" | "FAILED";
            startedAt: string;
            requestHash?: string | undefined;
            finishedAt?: string | undefined;
            before?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            after?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            executions?: {
                before?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
                after?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
            } | undefined;
            error?: string | undefined;
        }[];
        instruction?: string | undefined;
        rationale?: string | undefined;
        applicability?: string | undefined;
        evidence?: {
            operationId: string;
            quote: string;
        }[] | undefined;
        previousId?: string | null | undefined;
        error?: string | undefined;
    }>;
    decide(workId: string, raw: unknown): Promise<{
        id: string;
        workId: string;
        accountId: string | null;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
        createdAt: string;
        fingerprint: string;
        foundationHash: string;
        baselineHash: string;
        feedback: {
            id: string;
            text: string;
        }[];
        acceptedOutputHash: string;
        comparisons: {
            id: string;
            workId: string;
            inputHash: string;
            methodHash: string;
            instructionHash: string;
            status: "RUNNING" | "SUCCEEDED" | "FAILED";
            startedAt: string;
            requestHash?: string | undefined;
            finishedAt?: string | undefined;
            before?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            after?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            executions?: {
                before?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
                after?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
            } | undefined;
            error?: string | undefined;
        }[];
        instruction?: string | undefined;
        rationale?: string | undefined;
        applicability?: string | undefined;
        evidence?: {
            operationId: string;
            quote: string;
        }[] | undefined;
        previousId?: string | null | undefined;
        error?: string | undefined;
    }>;
    rollback(workId: string, raw: unknown): Promise<{
        id: string;
        workId: string;
        accountId: string | null;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        status: "FAILED" | "NONE" | "ANALYZING" | "PENDING" | "ACTIVE" | "RETIRED" | "REJECTED";
        createdAt: string;
        fingerprint: string;
        foundationHash: string;
        baselineHash: string;
        feedback: {
            id: string;
            text: string;
        }[];
        acceptedOutputHash: string;
        comparisons: {
            id: string;
            workId: string;
            inputHash: string;
            methodHash: string;
            instructionHash: string;
            status: "RUNNING" | "SUCCEEDED" | "FAILED";
            startedAt: string;
            requestHash?: string | undefined;
            finishedAt?: string | undefined;
            before?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            after?: {
                message: string;
                output: {
                    title: string;
                    body: string;
                    cards: {
                        title: string;
                        body: string;
                    }[];
                };
                review: string[];
                sourceMap: string[];
                conception?: {
                    title: string;
                    core: string;
                    outline: string;
                    evidence: string;
                    boundaries: string;
                } | undefined;
                check?: {
                    status: "CHECKED" | "NEEDS_AUTHOR" | "INCOMPLETE";
                    issues: {
                        location: string;
                        problem: string;
                        evidence: string;
                        suggestion: string;
                        needsAuthor: boolean;
                        quote?: string | undefined;
                    }[];
                    repaired: boolean;
                    reason?: "CONNECTION" | "FORMAT" | "UNGROUNDED" | "REPAIR_FAILED" | undefined;
                    diagnostic?: string | undefined;
                } | undefined;
                authorQuestions?: {
                    problem: string;
                    evidence: string;
                    suggestion: string;
                    location: string;
                    needsAuthor: boolean;
                    quote?: string | undefined;
                }[] | undefined;
                editScope?: {
                    type: "ALL" | "TITLE" | "BODY" | "CARD";
                    cardIndex?: number | undefined;
                } | undefined;
                nextSteps?: {
                    label: string;
                    reason: string;
                    prompt: string;
                }[] | undefined;
                role?: "revision" | "proposal" | undefined;
                importKind?: "MANUSCRIPT" | undefined;
            } | undefined;
            executions?: {
                before?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
                after?: {
                    runtime: "molis-work";
                    runRef: {
                        runId: string;
                        sessionId: string;
                    };
                    configuredModel: {
                        providerId: string;
                        modelId: string;
                    };
                    phase: string;
                    observedAt: string;
                    startedAt: string | null;
                    endedAt: string | null;
                    usage: {
                        input: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        output: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cachedInput: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        cacheCreation: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                        costUsd: {
                            value: number | null;
                            coverage: "unknown" | "partial" | "reported" | "estimated" | "partial-estimated";
                        };
                    };
                    stopReason?: string | undefined;
                } | undefined;
            } | undefined;
            error?: string | undefined;
        }[];
        instruction?: string | undefined;
        rationale?: string | undefined;
        applicability?: string | undefined;
        evidence?: {
            operationId: string;
            quote: string;
        }[] | undefined;
        previousId?: string | null | undefined;
        error?: string | undefined;
    }>;
}
