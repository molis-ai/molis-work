import { z } from "zod";
import type { ActionDefinition, ActionExecutionContext } from "@molis-ai/molis-work-contracts/platform/actions";
import type { CgsCore } from "../cgs-core/index.ts";
import type { CgsWorkFiles } from "./files.ts";
export declare function operation<T extends z.ZodType>(name: string, title: string, schema: T, write: boolean, run: (core: CgsCore, input: z.infer<T>, caller: ActionExecutionContext, files: CgsWorkFiles) => Promise<unknown>, options?: {
    version?: number;
    needsModel?: boolean;
    timeoutMs?: number;
    modelCost?: "none" | "metered";
    needsControl?: boolean;
    userOnly?: boolean;
    agentAccessible?: boolean;
    description?: string;
    output?: z.ZodType;
    resultView?: ActionDefinition["action"]["result_view"];
    concurrent?: boolean;
}): {
    name: string;
    definition: ActionDefinition<unknown, unknown>;
    needsModel: boolean;
    needsControl: boolean;
    run: (core: CgsCore, input: unknown, caller: ActionExecutionContext, files: CgsWorkFiles) => Promise<unknown>;
};
