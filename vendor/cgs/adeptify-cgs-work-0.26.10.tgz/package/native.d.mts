export { cgsWorkFiles } from './types/packages/cgs-work/native-files.js';
export {createCgsWorkMaterials} from './types/packages/cgs-work/host-materials.js';
export {createCgsWorkModel} from './types/packages/cgs-work/host-model.mjs';
export declare const cgsPackageRoot:string;
