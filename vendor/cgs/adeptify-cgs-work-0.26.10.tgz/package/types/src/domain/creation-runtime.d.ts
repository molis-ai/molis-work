import { z } from "zod";
export declare const runtimeKindSchema: z.ZodEnum<{
    api: "api";
    codex: "codex";
    grok: "grok";
}>;
export type RuntimeKind = z.infer<typeof runtimeKindSchema>;
export declare const runtimeStatusSchema: z.ZodEnum<{
    ready: "ready";
    not_installed: "not_installed";
    incompatible: "incompatible";
    not_logged_in: "not_logged_in";
    connection_failed: "connection_failed";
}>;
export type RuntimeStatusCode = z.infer<typeof runtimeStatusSchema>;
export declare const runtimeSessionSchema: z.ZodObject<{
    threadId: z.ZodOptional<z.ZodString>;
    sessionId: z.ZodOptional<z.ZodString>;
    stale: z.ZodOptional<z.ZodBoolean>;
    snapshotHash: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type RuntimeSession = z.infer<typeof runtimeSessionSchema>;
export declare const runtimeSelectionSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        api: "api";
        codex: "codex";
        grok: "grok";
    }>;
    executable: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type RuntimeSelection = z.infer<typeof runtimeSelectionSchema>;
export declare const creationRuntimeStateSchema: z.ZodObject<{
    selection: z.ZodObject<{
        kind: z.ZodEnum<{
            api: "api";
            codex: "codex";
            grok: "grok";
        }>;
        executable: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    sessions: z.ZodOptional<z.ZodObject<{
        codex: z.ZodOptional<z.ZodObject<{
            threadId: z.ZodOptional<z.ZodString>;
            sessionId: z.ZodOptional<z.ZodString>;
            stale: z.ZodOptional<z.ZodBoolean>;
            snapshotHash: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        grok: z.ZodOptional<z.ZodObject<{
            threadId: z.ZodOptional<z.ZodString>;
            sessionId: z.ZodOptional<z.ZodString>;
            stale: z.ZodOptional<z.ZodBoolean>;
            snapshotHash: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type CreationRuntimeState = z.infer<typeof creationRuntimeStateSchema>;
export declare const methodRuntimeSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        api: "api";
        codex: "codex";
        grok: "grok";
    }>;
    label: z.ZodString;
    workId: z.ZodOptional<z.ZodString>;
    executable: z.ZodOptional<z.ZodString>;
    session: z.ZodOptional<z.ZodObject<{
        threadId: z.ZodOptional<z.ZodString>;
        sessionId: z.ZodOptional<z.ZodString>;
        stale: z.ZodOptional<z.ZodBoolean>;
        snapshotHash: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type MethodRuntime = z.infer<typeof methodRuntimeSchema>;
export type RuntimeDescriptor = {
    kind: RuntimeKind;
    label: string;
    status: RuntimeStatusCode;
    nextStep: string;
    executable?: string;
    version?: string;
    configuredCommand?: string;
    model?: string;
    effort?: string;
};
export declare function runtimeLabel(kind: RuntimeKind, apiLabel?: string): string;
export declare function runtimeUnavailableMessage(status: RuntimeStatusCode, kind: Exclude<RuntimeKind, "api">): string;
