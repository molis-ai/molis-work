export declare function parseRuntimeCommand(raw: string): string;
export declare function expandHome(command: string, home?: string): string;
export declare function canonicalPath(path: string): string;
export declare function searchDirectories(pathEnvironment?: string, home?: string): string[];
export declare function resolveExecutable(command: string, options?: {
    pathEnvironment?: string;
    home?: string;
}): string | undefined;
export declare function listNamedExecutables(name: string, options?: {
    pathEnvironment?: string;
    home?: string;
    extra?: string[];
}): string[];
export declare function versionRank(version?: string): number[];
export declare function isNewerVersion(a?: string, b?: string): boolean;
