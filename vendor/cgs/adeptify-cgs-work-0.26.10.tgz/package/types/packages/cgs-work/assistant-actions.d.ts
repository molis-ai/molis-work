/** Opt-in assistant projections. Full archives, adoption and approval remain
 * human-only; identity and private storage come from the Runtime caller. */
export declare const assistantOperations: {
    name: string;
    definition: import("@molis-ai/molis-work-plugin-sdk").ActionDefinition<unknown, unknown>;
    needsModel: boolean;
    needsControl: boolean;
    run: (core: import("../cgs-core/index.ts").CgsCore, input: unknown, caller: import("@molis-ai/molis-work-plugin-sdk").ActionExecutionContext, files: import("./files.ts").CgsWorkFiles) => Promise<unknown>;
}[];
