import { z } from 'zod';
/** Author-provided text only. File bytes and URL extraction stay with the
 * trusted material ports; this is not an import or private-library bypass. */
export declare const initialCreationSchema: z.ZodObject<{
    text: z.ZodString;
    materials: z.ZodDefault<z.ZodArray<z.ZodObject<{
        name: z.ZodString;
        text: z.ZodString;
    }, z.core.$strict>>>;
    account: z.ZodDefault<z.ZodNullable<z.ZodObject<{
        name: z.ZodString;
        audience: z.ZodString;
        voice: z.ZodString;
        boundaries: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export declare function initialCreationSource(id: string, input: z.infer<typeof initialCreationSchema>): {
    text: string;
    files: {
        id: string;
        name: string;
        text: string;
        provenance?: {
            sourceId: string;
            role: "ORIGINAL" | "REPORT";
            readScope: "FULL" | "PARTIAL" | "REFERENCE_ONLY";
            originalUrl?: string | undefined;
            observedAt?: string | undefined;
            publishedAt?: string | undefined;
        } | undefined;
        extraction?: {
            extractor: string;
            coverage: {
                status: "sufficient" | "partial" | "insufficient";
                processed_pages: number;
                total_pages: number;
                issues: string[];
                truncated?: boolean | undefined;
            };
            locations: {
                text: string;
                page?: number | undefined;
                start_seconds?: number | undefined;
                end_seconds?: number | undefined;
            }[];
            duration_seconds?: number | undefined;
        } | undefined;
        attachment?: {
            id: string;
            format: "PDF" | "DOCX" | "TEXT" | "IMAGE" | "AUDIO" | "VIDEO";
            size: number;
            sha256?: string | undefined;
            pages?: number | undefined;
            needsOcr?: boolean | undefined;
        } | undefined;
        intents?: ("SUPPORT" | "EXPLORE" | "COMPARE" | "EXPRESSION")[] | undefined;
        focus?: string | undefined;
        excluded?: boolean | undefined;
        processing?: {
            id: string;
            status: "FAILED" | "READING" | "UNDERSTANDING" | "READY" | "NEEDS_LOGIN";
            message: string;
            context: string;
        } | undefined;
        insight?: {
            summary: string;
            relation: string;
            next: string;
            quote: string;
            nextSteps?: {
                label: string;
                reason: string;
                prompt: string;
            }[] | undefined;
            nextStepsBasis?: string | undefined;
            nextStepsAt?: string | undefined;
        } | undefined;
        originalText?: string | undefined;
        url?: string | undefined;
        resolvedUrl?: string | undefined;
        retrievedAt?: string | undefined;
        kind?: "WEB_TEXT" | "VIDEO_TRANSCRIPT" | "AUDIO_TRANSCRIPT" | "USER_TRANSCRIPT" | "DOCUMENT_TEXT" | "IMAGE_TEXT" | "FEED_DIRECTORY" | undefined;
    }[];
};
