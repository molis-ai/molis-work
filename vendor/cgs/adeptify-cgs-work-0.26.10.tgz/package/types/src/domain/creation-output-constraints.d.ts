import { z } from 'zod';
/** Explicit per-request limits, never inferred from old chat or platform folklore. */
export declare const outputConstraintsSchema: z.ZodObject<{
    bodyMinCharacters: z.ZodOptional<z.ZodNumber>;
    bodyMaxCharacters: z.ZodOptional<z.ZodNumber>;
    cardCount: z.ZodOptional<z.ZodNumber>;
    cardMaxCharacters: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type OutputConstraints = z.infer<typeof outputConstraintsSchema>;
export declare function validateOutputConstraints(output: {
    body: string;
    cards: {
        body: string;
    }[];
}, limits?: OutputConstraints): void;
