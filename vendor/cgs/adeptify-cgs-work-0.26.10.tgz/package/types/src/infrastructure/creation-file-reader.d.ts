export declare const MAX_DOCUMENT_BYTES: number;
export type ParsedDocument = {
    format: "PDF" | "DOCX";
    text: string;
    html: string;
    pages?: number;
    needsOcr?: boolean;
};
export declare function readCreationFile(name: string, bytes: Buffer, { signal }?: {
    signal?: AbortSignal;
}): Promise<ParsedDocument>;
