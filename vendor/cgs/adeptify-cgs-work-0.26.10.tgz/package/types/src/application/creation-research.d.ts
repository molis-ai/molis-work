import { type Creation } from "../domain/creation.ts";
import type { CreationStore } from "../storage/creation-store.ts";
import type { CreationModel } from "./creation-model.ts";
import type { EvidenceAcquisitionPort } from "./evidence-acquisition.ts";
import { type UrlReadResult } from "../infrastructure/creation-url-reader.ts";
export type ResearchDependencies = {
    acquisition?: EvidenceAcquisitionPort;
    read?: (url: string) => Promise<UrlReadResult>;
    deadlineMs?: number;
};
/** Public questions only; private drafts are never sent to search or to the research judge. */
export declare class CreationResearch {
    private jobs;
    private store;
    private resolve;
    private deps;
    constructor(store: CreationStore, resolve: (doc: Creation) => Promise<CreationModel>, deps?: ResearchDependencies);
    recover(): Promise<void>;
    start(workId: string, raw: unknown): Promise<Creation>;
    cancel(workId: string, raw: unknown): Promise<Creation>;
    attach(workId: string, raw: unknown): Promise<Creation>;
    private execute;
}
