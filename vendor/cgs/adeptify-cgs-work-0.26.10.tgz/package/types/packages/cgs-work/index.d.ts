import { type PluginDefinition } from "@molis-ai/molis-work-plugin-sdk";
import { type ActionAvailability, type ActionExecutionContext } from "@molis-ai/molis-work-contracts/platform/actions";
import type { PluginStartContext } from "@molis-ai/molis-work-contracts/platform/plugin";
import { type CreationModel } from "../cgs-core/index.ts";
import type { CgsWorkFiles } from "./files.ts";
import type { CreationMaterialPorts } from '../../src/application/creation-material-ports.ts';
export declare const CGS_WORK_PLUGIN_ID = "io.molis.work.cgs";
export declare const CGS_WORK_PLUGIN_VERSION = "0.26.10";
/** Trusted assembly port, never supplied by request JSON. Its implementation
 * must use this Home's Prologue, editable registered prompts, and recheck this
 * caller before every nested dispatch. Availability is metadata-only. A legacy
 * direct API/CLI CreationModel is not a Work runtime adapter. */
export interface CgsWorkModelPort {
    availability(): ActionAvailability;
    bind(caller: ActionExecutionContext): Pick<CreationModel, "available" | "label" | "unavailableMessage" | "method" | "run" | "editorial"> & {
        /** Synchronous: after authorization, immediately before storage CAS. */
        assertCurrent?(): void;
    };
}
/** Headless integration slice, not yet a distributable CGS UI.
 * The Host supplies identity, Actions and installation-scoped storage. No
 * database, actor, project, credentials or model runtime comes from input JSON.
 */
export declare function createCgsWorkPlugin(ports?: {
    model?: CgsWorkModelPort;
    files?: CgsWorkFiles;
    materialsFor?: (caller: ActionExecutionContext) => CreationMaterialPorts;
    /** Shipped method body, read by the trusted package loader; never request JSON. */
    assistantMethodBody?: string;
    assistantMethods?: import("@molis-ai/molis-work-contracts/platform/plugin-agent").AgentSkillDefinition[];
    /** Trusted per-activation assembly; never a model factory supplied by the UI. */
    modelFor?: (context: PluginStartContext) => Promise<CgsWorkModelPort & {
        dispose(): Promise<void>;
    }>;
    ui?: {
        renderCreation(): string;
        client?: {
            module_route: string;
            stylesheet_route?: string;
        };
        assets?: readonly {
            route_id: string;
            path: string;
            mime: string;
            bytes: Uint8Array;
        }[];
    };
}): PluginDefinition;
