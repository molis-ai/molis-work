import { type Operation } from "../domain/creation.ts";
import { CreationToolSession, type ToolSessionOptions } from "./creation-tools.ts";
export type CreationTurnOptions = Pick<ToolSessionOptions, "provider" | "references" | "progress" | "parseResult">;
/** Shared business preparation, not a model runner or persistence authority.
 * Instructions come from this operation's frozen effective method; a Host must
 * resolve registered/user-edited prompts before freezing it. References are
 * already scoped by the caller. Tools only produce a candidate for the core.
 */
export declare function prepareCreationTurn(source: Operation, options: CreationTurnOptions): {
    operation: Operation;
    session: CreationToolSession;
    instructions: string;
    guide: (paths: string[]) => string;
    producePaths: string[];
    layout: {
        aspectRatio: string;
        maxCards: number;
        maxCardTitleCharacters: number;
        maxCardBodyCharacters: number;
    };
    writingPreferences: {
        field: "audience" | "voice" | "boundaries";
        text: string;
    }[];
};
