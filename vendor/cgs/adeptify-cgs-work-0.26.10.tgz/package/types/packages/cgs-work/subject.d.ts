import type { ActionDefinition } from "@molis-ai/molis-work-contracts/platform/actions";
import type { CgsCore } from "../cgs-core/index.ts";
export declare const cgsSubjectReader: {
    name: string;
    definition: ActionDefinition<unknown, unknown>;
    needsModel: boolean;
    needsControl: boolean;
    run(core: CgsCore, raw: unknown): Promise<import("@molis-ai/molis-work-plugin-sdk").ActionSubjectContext>;
};
