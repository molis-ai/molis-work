import {createRequire as __cgsRequire} from "node:module"; const require = __cgsRequire(process.execPath);

// src/infrastructure/creation-original-preview-worker.ts
import { parentPort, workerData } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import { GlobalFonts } from "@napi-rs/canvas";
try {
  const cjkSerif = ["Songti SC", "Noto Serif CJK SC", "Noto Serif SC", "Source Han Serif SC", "SimSun"].find((name) => GlobalFonts.has(name));
  if (cjkSerif) for (const alias of ["STSongStd", "STSong", "STSong-Light"]) {
    if (!GlobalFonts.has(alias)) GlobalFonts.setAlias(cjkSerif, alias);
  }
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const task = getDocument({
    data: new Uint8Array(workerData.bytes),
    useSystemFonts: true,
    cMapUrl: fileURLToPath(new URL("./cmaps/", import.meta.resolve("pdfjs-dist/package.json"))),
    cMapPacked: true,
    standardFontDataUrl: fileURLToPath(new URL("./standard_fonts/", import.meta.resolve("pdfjs-dist/package.json"))),
    wasmUrl: fileURLToPath(new URL("./wasm/", import.meta.resolve("pdfjs-dist/package.json")))
  });
  try {
    const pdf = await task.promise, pageNumber = workerData.page;
    if (pdf.numPages > 200 || pageNumber > pdf.numPages) throw new Error("\u9884\u89C8\u9875\u7801\u8D85\u51FA\u6587\u4EF6\u8303\u56F4\uFF0C\u8BF7\u91CD\u65B0\u9009\u62E9\u9875\u7801\u3002");
    const page = await pdf.getPage(pageNumber), natural = page.getViewport({ scale: 1 });
    const viewport = page.getViewport({ scale: Math.min(2, 1200 / natural.width, 1800 / natural.height) });
    const width = Math.max(1, Math.floor(viewport.width)), height = Math.max(1, Math.floor(viewport.height));
    const factory = pdf.canvasFactory;
    const surface = factory.create(width, height);
    try {
      await page.render({ canvasContext: surface.context, canvas: surface.canvas, viewport }).promise;
      const image = surface.canvas.toBuffer("image/png");
      if (image.length > 8 * 1024 * 1024) throw new Error("\u8FD9\u9875\u9884\u89C8\u56FE\u7247\u8FC7\u5927\uFF0C\u8BF7\u4E0B\u8F7D\u539F\u6587\u4EF6\u6838\u5BF9\u3002");
      parentPort.postMessage({ page: pageNumber, totalPages: pdf.numPages, width, height, pngBase64: image.toString("base64") });
    } finally {
      factory.destroy(surface);
      page.cleanup();
    }
  } finally {
    await task.destroy();
  }
} catch (error) {
  parentPort.postMessage({ error: error instanceof Error && /[\u4e00-\u9fff]/.test(error.message) ? error.message : "\u6587\u4EF6\u9884\u89C8\u5931\u8D25\uFF0C\u8BF7\u4E0B\u8F7D\u539F\u6587\u4EF6\u6838\u5BF9\u3002" });
}
