import { type Material } from "../domain/creation.ts";
import { type ParsedDocument } from "./creation-file-reader.ts";
export { publicMaterialUrl } from "./creation-public-fetch.ts";
export type UrlReadResult = {
    status: "READY";
    material: Material;
    notice: string;
} | {
    status: "UNAVAILABLE" | "NEEDS_LOGIN";
    kind: string;
    url: string;
    message: string;
    title?: string;
};
export type UrlReaderOptions = {
    saveDocument?: (bytes: Buffer, parsed: ParsedDocument) => Promise<string>;
    transcribe?: (file: string, title: string, progress?: (message: string) => Promise<void>) => Promise<string>;
    ocr?: (file: string, progress?: (message: string) => Promise<void>) => Promise<string>;
};
export declare function linkedContentType(name: string, mime: string, prefix: Buffer): string;
export declare function subtitleText(raw: string): string;
export declare function readCreationUrl(input: unknown, fetchFn?: typeof fetch, onProgress?: (message: string) => Promise<void>, options?: UrlReaderOptions): Promise<UrlReadResult>;
export declare function runMaterialReader(program: string, args: string[], env: NodeJS.ProcessEnv, onProgress?: (message: string) => Promise<void>, timeout?: number): Promise<Record<string, any>>;
