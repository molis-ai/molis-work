/** In-memory cancellation handles for ONE trusted owner/store.
 * No author data, grants, model credentials, or persisted task truth live here.
 * Do not share this scope across Home/user/installation boundaries.
 */
export type CreationExecutionScope = {
    readonly jobs: Map<string, {
        abort: AbortController;
        token: symbol;
    }>;
};
export declare function createCreationExecutionScope(): CreationExecutionScope;
