import type { MaterialExtractor, MaterialWebsiteReader, MaterialDocumentReader } from '@molis-ai/molis-work-contracts/services/materials';
import type { CreationMaterialPorts } from '../../src/application/creation-material-ports.ts';
type Ports = {
    extract: MaterialExtractor;
    documents: MaterialDocumentReader;
    website: MaterialWebsiteReader;
};
type Control = {
    signal?: AbortSignal;
    beforeEffect(): Promise<void>;
};
/** Trusted per-Action adapter. Parsing, HTTP, native helpers and their bounds
 * belong to Work; CGS owns source identities, scope, originals and purpose. */
export declare function createCgsWorkMaterials(ports: Ports, caller: Control): CreationMaterialPorts;
export {};
