import { z } from "zod";
import { researchNeedSchema } from "./topic-review.ts";
export { researchNeedSchema };
export declare const researchSuggestionSchema: z.ZodObject<{
    question: z.ZodString;
    impact: z.ZodString;
    evidenceNeeded: z.ZodArray<z.ZodString>;
    stopWhen: z.ZodString;
    query: z.ZodString;
}, z.core.$strict>;
export declare const researchConclusionSchema: z.ZodObject<{
    verdict: z.ZodEnum<{
        SUPPORTED: "SUPPORTED";
        CONTRADICTED: "CONTRADICTED";
        UNRESOLVED: "UNRESOLVED";
    }>;
    summary: z.ZodString;
    evidence: z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        quote: z.ZodString;
        claim: z.ZodString;
    }, z.core.$strict>>;
    followup: z.ZodNullable<z.ZodObject<{
        query: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const researchSourceSchema: z.ZodObject<{
    id: z.ZodString;
    title: z.ZodString;
    url: z.ZodURL;
    text: z.ZodString;
    kind: z.ZodOptional<z.ZodEnum<{
        WEB_TEXT: "WEB_TEXT";
        VIDEO_TRANSCRIPT: "VIDEO_TRANSCRIPT";
        AUDIO_TRANSCRIPT: "AUDIO_TRANSCRIPT";
        USER_TRANSCRIPT: "USER_TRANSCRIPT";
        DOCUMENT_TEXT: "DOCUMENT_TEXT";
        IMAGE_TEXT: "IMAGE_TEXT";
        FEED_DIRECTORY: "FEED_DIRECTORY";
    }>>;
    readScope: z.ZodEnum<{
        FULL: "FULL";
        PARTIAL: "PARTIAL";
    }>;
    role: z.ZodEnum<{
        ORIGINAL: "ORIGINAL";
        REPORT: "REPORT";
    }>;
    observedAt: z.ZodString;
    notice: z.ZodString;
}, z.core.$strict>;
export declare const researchSelectionSchema: z.ZodObject<{
    verdict: z.ZodEnum<{
        SUPPORTED: "SUPPORTED";
        CONTRADICTED: "CONTRADICTED";
        UNRESOLVED: "UNRESOLVED";
    }>;
    summary: z.ZodString;
    followup: z.ZodNullable<z.ZodObject<{
        query: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>;
    evidence: z.ZodArray<z.ZodObject<{
        passageId: z.ZodNumber;
        claim: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare function researchModelInput(raw: unknown): {
    sources: {
        id: string;
        title: string;
        url: string;
        readScope: "FULL" | "PARTIAL";
        role: "ORIGINAL" | "REPORT";
        observedAt: string;
        notice: string;
        kind?: "WEB_TEXT" | "VIDEO_TRANSCRIPT" | "AUDIO_TRANSCRIPT" | "USER_TRANSCRIPT" | "DOCUMENT_TEXT" | "IMAGE_TEXT" | "FEED_DIRECTORY" | undefined;
    }[];
    passages: {
        id: number;
        sourceId: string;
        text: string;
    }[];
    question: string;
    round: number;
};
export declare function resolveResearchSelection(raw: unknown, input: unknown): {
    verdict: "SUPPORTED" | "CONTRADICTED" | "UNRESOLVED";
    summary: string;
    evidence: {
        sourceId: string;
        quote: string;
        claim: string;
    }[];
    followup: {
        query: string;
        reason: string;
    } | null;
};
export declare const creationResearchSchema: z.ZodObject<{
    id: z.ZodString;
    fingerprint: z.ZodString;
    need: z.ZodObject<{
        question: z.ZodString;
        impact: z.ZodString;
        evidenceNeeded: z.ZodArray<z.ZodString>;
        stopWhen: z.ZodString;
    }, z.core.$strict>;
    query: z.ZodString;
    status: z.ZodEnum<{
        RUNNING: "RUNNING";
        SUCCEEDED: "SUCCEEDED";
        FAILED: "FAILED";
        CANCELLED: "CANCELLED";
    }>;
    startedAt: z.ZodString;
    finishedAt: z.ZodOptional<z.ZodString>;
    progress: z.ZodString;
    sources: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        title: z.ZodString;
        url: z.ZodURL;
        text: z.ZodString;
        kind: z.ZodOptional<z.ZodEnum<{
            WEB_TEXT: "WEB_TEXT";
            VIDEO_TRANSCRIPT: "VIDEO_TRANSCRIPT";
            AUDIO_TRANSCRIPT: "AUDIO_TRANSCRIPT";
            USER_TRANSCRIPT: "USER_TRANSCRIPT";
            DOCUMENT_TEXT: "DOCUMENT_TEXT";
            IMAGE_TEXT: "IMAGE_TEXT";
            FEED_DIRECTORY: "FEED_DIRECTORY";
        }>>;
        readScope: z.ZodEnum<{
            FULL: "FULL";
            PARTIAL: "PARTIAL";
        }>;
        role: z.ZodEnum<{
            ORIGINAL: "ORIGINAL";
            REPORT: "REPORT";
        }>;
        observedAt: z.ZodString;
        notice: z.ZodString;
    }, z.core.$strict>>;
    skippedSources: z.ZodOptional<z.ZodArray<z.ZodObject<{
        url: z.ZodURL;
        title: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>>;
    failureStage: z.ZodOptional<z.ZodEnum<{
        SEARCH: "SEARCH";
        READ: "READ";
        ANALYSIS: "ANALYSIS";
        EVIDENCE: "EVIDENCE";
        DEADLINE: "DEADLINE";
    }>>;
    rounds: z.ZodArray<z.ZodObject<{
        query: z.ZodString;
        reason: z.ZodString;
        provider: z.ZodString;
        found: z.ZodNumber;
        conclusion: z.ZodOptional<z.ZodObject<{
            verdict: z.ZodEnum<{
                SUPPORTED: "SUPPORTED";
                CONTRADICTED: "CONTRADICTED";
                UNRESOLVED: "UNRESOLVED";
            }>;
            summary: z.ZodString;
            evidence: z.ZodArray<z.ZodObject<{
                sourceId: z.ZodString;
                quote: z.ZodString;
                claim: z.ZodString;
            }, z.core.$strict>>;
            followup: z.ZodNullable<z.ZodObject<{
                query: z.ZodString;
                reason: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    conclusion: z.ZodOptional<z.ZodObject<{
        verdict: z.ZodEnum<{
            SUPPORTED: "SUPPORTED";
            CONTRADICTED: "CONTRADICTED";
            UNRESOLVED: "UNRESOLVED";
        }>;
        summary: z.ZodString;
        evidence: z.ZodArray<z.ZodObject<{
            sourceId: z.ZodString;
            quote: z.ZodString;
            claim: z.ZodString;
        }, z.core.$strict>>;
        followup: z.ZodNullable<z.ZodObject<{
            query: z.ZodString;
            reason: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    stopReason: z.ZodOptional<z.ZodEnum<{
        FAILED: "FAILED";
        CANCELLED: "CANCELLED";
        ANSWERED: "ANSWERED";
        BUDGET: "BUDGET";
        NO_EVIDENCE: "NO_EVIDENCE";
    }>>;
    error: z.ZodOptional<z.ZodString>;
    attachedIds: z.ZodOptional<z.ZodArray<z.ZodString>>;
}, z.core.$strict>;
export type CreationResearchRun = z.infer<typeof creationResearchSchema>;
export type ResearchConclusion = z.infer<typeof researchConclusionSchema>;
