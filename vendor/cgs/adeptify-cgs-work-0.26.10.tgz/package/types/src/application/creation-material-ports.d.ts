import type { Material } from '../domain/creation.ts';
import type { AttachmentFormat, MaterialExtractionRecord } from '../domain/creation-material-extraction.ts';
export interface CreationMaterialPorts {
    readFile(name: string, bytes: Buffer, control: {
        signal?: AbortSignal;
    }): Promise<{
        format: AttachmentFormat;
        text: string;
        html: string;
        pages?: number;
        needsOcr?: boolean;
        kind?: Material['kind'];
        extraction?: MaterialExtractionRecord;
    }>;
    readUrl(url: string, control: {
        signal?: AbortSignal;
    }): Promise<{
        name: string;
        text: string;
        kind?: Material['kind'];
        extraction: MaterialExtractionRecord;
    }>;
}
