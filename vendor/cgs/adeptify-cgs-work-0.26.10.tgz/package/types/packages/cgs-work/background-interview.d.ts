import { z } from "zod";
import type { ActionExecutionContext } from "@molis-ai/molis-work-contracts/platform/actions";
import type { CgsCore } from "../cgs-core/index.ts";
export declare const interviewInputs: {
    interviewread: z.ZodObject<{
        id: z.ZodString;
        expected_revision: z.ZodNumber;
    }, z.core.$strict>;
    interviewstart: z.ZodObject<{
        id: z.ZodString;
        expected_revision: z.ZodNumber;
        name: z.ZodString;
    }, z.core.$strict>;
    interviewsave: z.ZodObject<{
        id: z.ZodString;
        expected_revision: z.ZodNumber;
        interviewId: z.ZodString;
        interviewRevision: z.ZodNumber;
        name: z.ZodString;
        answers: z.ZodRecord<z.ZodEnum<{
            value: "value";
            experience: "experience";
            opinions: "opinions";
            curiosity: "curiosity";
            ai: "ai";
            style: "style";
            publishing: "publishing";
            audience: "audience";
            voice: "voice";
            boundaries: "boundaries";
        }>, z.ZodString>;
        skipped: z.ZodArray<z.ZodEnum<{
            value: "value";
            experience: "experience";
            opinions: "opinions";
            curiosity: "curiosity";
            ai: "ai";
            style: "style";
            publishing: "publishing";
            audience: "audience";
            voice: "voice";
            boundaries: "boundaries";
        }>>;
    }, z.core.$strict>;
    interviewconfirm: z.ZodObject<{
        id: z.ZodString;
        expected_revision: z.ZodNumber;
        interviewId: z.ZodString;
        interviewRevision: z.ZodNumber;
        confirmed: z.ZodLiteral<true>;
        saveAsNew: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>;
};
export type InterviewAction = keyof typeof interviewInputs;
export declare function runBackgroundInterview(core: CgsCore, name: InterviewAction, input: unknown, caller: ActionExecutionContext): Promise<{
    work: import("../../src/domain/creation.ts").Creation;
    interview: {
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    } | {
        externalChanged: boolean;
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    } | null;
    account?: undefined;
} | {
    work: import("../../src/domain/creation.ts").Creation;
    interview: {
        id: string;
        scope: {
            userId: string;
            accountId: string | null;
        };
        revision: number;
        backgroundId: string;
        name: string;
        answers: Record<"value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries", string>;
        skipped: ("value" | "experience" | "opinions" | "curiosity" | "ai" | "style" | "publishing" | "audience" | "voice" | "boundaries")[];
        expectedHash: string;
        savedAt: string | null;
        updatedAt: string;
        lastSave?: {
            revision: number;
            hash: string;
        } | undefined;
    };
    account: {
        id: string;
        name: string;
        audience: string;
        voice: string;
        boundaries: string;
        profile?: {
            experience: string;
            opinions: string;
            value: string;
            curiosity: string;
            ai: string;
            style: string;
            publishing: string;
        } | undefined;
    };
}>;
