import { type Creation, type Material } from "./creation.ts";
export type SavedMaterial = {
    id: string;
    savedAt: string;
    material: Material;
};
type CatalogState = {
    creations: Creation[];
    materials?: SavedMaterial[];
};
export declare function sourceContent(file: Material): Material;
export declare function sourceKey(file: Material): string;
export declare function retainMaterial(entries: SavedMaterial[], file: Material, at: string): SavedMaterial;
export declare function materialCatalog(state: CatalogState): SavedMaterial[];
export {};
