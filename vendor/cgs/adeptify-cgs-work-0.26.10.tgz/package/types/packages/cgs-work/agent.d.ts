import type { AgentManifest } from "@molis-ai/molis-work-contracts/platform/plugin-agent";
export declare const cgsWorkAssistantMethods: {
    skill_id: string;
    version: number;
    name: string;
    summary: string;
    tools: string[];
}[];
export declare const cgsWorkAssistantMethod: {
    skill_id: string;
    version: number;
    name: string;
    summary: string;
    tools: string[];
};
export declare const cgsWorkMethodPath: (id: string) => string;
/** One declaration for the Plugin manifest and its trusted model assembly. */
export declare const cgsWorkPromptPaths: readonly (readonly [string, string, number])[];
export declare const cgsWorkAgent: AgentManifest;
