# `@prologue/sdk`

要嵌入消费 App 的那一份 TypeScript 引擎。创建 Runtime、开会话、调模型、跑 Agent 和工具，都从这里进。

它规定合同和状态机，但不自己保管 API Key、不自己发 HTTP、不自己读写磁盘。这些交给原生 Host。App 只走包根公开入口，不 deep import。

## 现役模块

模块清单和各自职责见 [`src/README.md`](./src/README.md)。功能定义在 [`docs/product/requirements/`](../../docs/product/requirements/)，本包不复述。

现役树只包含已经做过的模块。需要新模块时由带来它的队列项新建，不预建空壳。

## 公开面的成熟度

根入口导出的名字分两档：

- **稳定**：有真实消费者在用，或是 `Runtime` 上分册定义的能力。破坏性变更走主版本。
- **experimental**：已实现、已测试，但**还没有真实消费者、或没接到 Runtime 上**——要么是独立的积木（调度、精炼、插件目录、数据源注册表……），要么是被顺手导出的内部常量。**可以用，但不承诺稳定**：有第二家 App 真去用之前，形状可以改，不走主版本。

名单（85 个值）在 [`test/public-surface.test.ts`](./test/public-surface.test.ts) 的 `EXPERIMENTAL`，导出快照 [`test/__snapshots__/public-surface.txt`](./test/__snapshots__/public-surface.txt) 里这些名字后面带 `[experimental]`。名单由测试守着：名字一旦被 `src` 里别的文件用上（说明接到生产代码上了），测试就红，要把它摘掉。`Runtime` 句柄上标 `@internal` 的三个成员（`random`、`assembled`、`defaults`）同理，不是稳定合同。

## 不做什么

不提供产品 UI。不拥有消费 App 的项目、任务和按钮状态。不在 JavaScript 里保存或读回 API Key。

## 验证

Node 消费 App 已持离线独占 owner 窗口时，可通过 `@prologue/sdk/node` 的 `verifyNodeStorageContents({ storageRoot, keyRoot, assertCurrent, signal? })` 认证既有归档的全部密封记录。`storageRoot` 是归档 SDK 数据根，`keyRoot` 是可信 Home/registry 映射选出的原 Home SDK 密钥根，两者须为现有绝对目录；快照时可相同。`assertCurrent` 必须同步，失效时抛出。成功只返回 `undefined`；没有密封记录时无需 key，成功也不证明 key 匹配。操作不创建/修改数据、密钥或 leases，不启动 Runtime、模型或恢复；错误脱敏，取消和当前性失效都拒绝成功交付。具体合同见[原子存储 slice](../../docs/slices/host-storage.md#node-离线全库密封认证c2-sdk-inspect)。

```bash
pnpm exec tsc -p tsconfig.typecheck.json --noEmit && pnpm exec vitest run packages/sdk/test
```

真实证据走 `test/*.live.test.ts`，需要仓库根 `.env.local` 里的 Key。缺 Key 时跳过，**跳过不算完成证据**。

下一项做什么看 [`docs/slices/requirement-order.md`](../../docs/slices/requirement-order.md)。
