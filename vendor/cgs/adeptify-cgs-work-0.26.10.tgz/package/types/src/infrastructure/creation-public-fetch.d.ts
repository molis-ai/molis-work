export declare function publicMaterialUrl(value: unknown): URL;
export declare function isPublicAddress(address: string): boolean;
export declare const fetchPublicContent: typeof fetch;
