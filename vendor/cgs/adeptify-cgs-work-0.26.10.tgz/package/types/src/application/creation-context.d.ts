import { type Account, type Creation, type Operation } from "../domain/creation.ts";
export declare function creationContext(doc: Creation, input: Operation["input"], preferences: Account | null, artifact?: Operation["artifact"]): {
    history: {
        feedback: string;
        response: string;
        operationId?: string;
        at?: string;
        context?: string;
    }[];
    references: {
        id: string;
        kind: string;
        title: string;
        at: string;
        hash: string;
    }[];
    memory: {
        omitted: number;
        preferences: {
            id: string;
            name: string;
            audience: string;
            voice: string;
            boundaries: string;
            profile?: {
                experience: string;
                opinions: string;
                value: string;
                curiosity: string;
                ai: string;
                style: string;
                publishing: string;
            } | undefined;
        } | null;
        decisions: string[];
    };
};
export declare function creationReferences(doc: Creation): Map<string, {
    kind: string;
    title: string;
    at: string;
    content: unknown;
}>;
