import { BackgroundInterviews } from "./background-interview.ts";
import { CreationMaterialLibrary } from "./creation-material-library.ts";
import { readCreationUrl } from "../infrastructure/creation-url-reader.ts";
import { z } from "zod";
import { type Material, type Creation, type Version } from "../domain/creation.ts";
import type { CreationStore } from "../storage/creation-store.ts";
import type { CreationModel } from "./creation-model.ts";
import { type RuntimeKind } from "../domain/creation-runtime.ts";
import { CreationResearch, type ResearchDependencies } from "./creation-research.ts";
import { CreationLearning } from "./creation-learning.ts";
import { type CreationExecutionScope } from "./creation-execution.ts";
import type { CreationMaterialPorts } from './creation-material-ports.ts';
export declare function worthOneMoreAttempt(error: unknown, runtime?: RuntimeKind): boolean;
export declare const operationSchema: z.ZodObject<{
    revision: z.ZodNumber;
    outputConstraints: z.ZodOptional<z.ZodObject<{
        bodyMinCharacters: z.ZodOptional<z.ZodNumber>;
        bodyMaxCharacters: z.ZodOptional<z.ZodNumber>;
        cardCount: z.ZodOptional<z.ZodNumber>;
        cardMaxCharacters: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    artifact: z.ZodOptional<z.ZodEnum<{
        MANUSCRIPT: "MANUSCRIPT";
        XIAOHONGSHU: "XIAOHONGSHU";
        WECHAT: "WECHAT";
        JIKE: "JIKE";
        ZHIHU: "ZHIHU";
        X: "X";
        DOUYIN_ARTICLE: "DOUYIN_ARTICLE";
        REDDIT: "REDDIT";
    }>>;
    refreshSource: z.ZodOptional<z.ZodBoolean>;
    batchId: z.ZodOptional<z.ZodString>;
    id: z.ZodString;
    mode: z.ZodDefault<z.ZodEnum<{
        AUTO: "AUTO";
        DISCUSS: "DISCUSS";
        CREATE: "CREATE";
        REVIEW: "REVIEW";
    }>>;
    kind: z.ZodEnum<{
        PLAN: "PLAN";
        GENERATE: "GENERATE";
    }>;
    adoptPlanId: z.ZodOptional<z.ZodString>;
    feedback: z.ZodString;
    target: z.ZodDiscriminatedUnion<[z.ZodObject<{
        type: z.ZodLiteral<"WORKING">;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"BASE">;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"PLAN_CANDIDATE">;
        operationId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"VERSION">;
        versionId: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        type: z.ZodLiteral<"RETRY">;
        operationId: z.ZodString;
    }, z.core.$strict>], "type">;
    applyIntent: z.ZodOptional<z.ZodEnum<{
        NONE: "NONE";
        AUTO: "AUTO";
        CREATE_DRAFT: "CREATE_DRAFT";
        REVISE: "REVISE";
        PROPOSE: "PROPOSE";
    }>>;
    citation: z.ZodOptional<z.ZodObject<{
        kind: z.ZodEnum<{
            TITLE: "TITLE";
            BODY: "BODY";
            PAGE: "PAGE";
            PLAN: "PLAN";
            OUTPUT: "OUTPUT";
        }>;
        page: z.ZodOptional<z.ZodNumber>;
        field: z.ZodOptional<z.ZodEnum<{
            title: "title";
            evidence: "evidence";
            boundaries: "boundaries";
            core: "core";
            outline: "outline";
        }>>;
        label: z.ZodString;
        issue: z.ZodOptional<z.ZodObject<{
            location: z.ZodString;
            quote: z.ZodOptional<z.ZodString>;
            problem: z.ZodString;
            evidence: z.ZodString;
            suggestion: z.ZodString;
            needsAuthor: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
/** A controlled request stopped after its RUNNING record was saved. Unlike a
 * cancellation refused before any effect, it may have reached the model; the
 * record is left for the author to check, never rerun or settled by this call. */
export declare class CreationStoppedAfterStartError extends Error {
    readonly code = "cgs.generation_stopped";
    constructor(cause: unknown);
}
export declare class CreationWorkspace {
    readonly research: CreationResearch;
    readonly learning: CreationLearning;
    readonly materialLibrary: CreationMaterialLibrary;
    private planComparisons;
    readonly interviews: BackgroundInterviews;
    private store;
    private model;
    private readMaterial;
    private jobs;
    private materials?;
    constructor(store: CreationStore, model: CreationModel, readMaterial?: typeof readCreationUrl, research?: ResearchDependencies, executionScope?: CreationExecutionScope, materials?: CreationMaterialPorts);
    private jobKey;
    /** Taken before the RUNNING record is committed and held until execution
     * ends, so no read observes that record without its execution handle. */
    private claim;
    private release;
    private executing;
    /** The saved work plus which RUNNING requests this owner is still executing.
     * A RUNNING record without its execution is not running: the invoking call
     * was cancelled, disconnected or ended with its activation, and had no
     * authority left to record an outcome. Reading never settles it; the author
     * ends it with a fresh explicit stop. */
    inspect(id: string): Promise<{
        work: Creation;
        executing: string[];
    }>;
    private resolvedModel;
    recover(): Promise<void>;
    list(): Promise<{
        modelAvailable: boolean;
        modelLabel: string;
        runtimes: never[];
        accounts: {
            id: string;
            name: string;
            audience: string;
            voice: string;
            boundaries: string;
            profile?: {
                experience: string;
                opinions: string;
                value: string;
                curiosity: string;
                ai: string;
                style: string;
                publishing: string;
            } | undefined;
        }[];
        materialCount: number;
        creations: {
            id: string;
            title: string;
            updatedAt: string;
            account: string;
            hasOutput: boolean;
            progress: import("../../web/creation-progress.js").CreationProgress;
            runtime: "api" | "codex" | "grok";
        }[];
    }>;
    topicPreferences(backgroundId?: string | null): Promise<{
        id: string;
        name: string;
        audience: string;
        voice: string;
        boundaries: string;
        profile?: {
            experience: string;
            opinions: string;
            value: string;
            curiosity: string;
            ai: string;
            style: string;
            publishing: string;
        } | undefined;
    } | null>;
    topicBackgrounds(): Promise<{
        id: string;
        name: string;
        audience: string;
        voice: string;
        boundaries: string;
        profile?: {
            experience: string;
            opinions: string;
            value: string;
            curiosity: string;
            ai: string;
            style: string;
            publishing: string;
        } | undefined;
    }[]>;
    topicLinks(scope?: {
        userId: string;
        accountId: string | null;
    }): Promise<{
        candidateId: string;
        creationId: string;
    }[]>;
    createFromTopic(input: unknown): Promise<{
        creationId: string;
        existing: boolean;
    }>;
    runtimes(force?: boolean): Promise<import("../domain/creation-runtime.ts").RuntimeDescriptor[]>;
    setExecutable(input: unknown): Promise<{
        runtimes: import("../domain/creation-runtime.ts").RuntimeDescriptor[];
    }>;
    setRuntime(id: string, input: unknown): Promise<Creation>;
    cancelOperation(id: string, input: unknown): Promise<Creation>;
    read(id: string): Promise<Creation>;
    comparePlan(id: string, input: unknown): Promise<{
        comparison: {
            direction: "SAME_DIRECTION" | "NEW_ANGLE" | "OPPOSITE" | "UNCERTAIN";
            summary: string;
            currentView: string;
            proposedView: string;
            reason: string;
            tradeoff: string;
            anchors: {
                before: string;
                after: string;
            };
        };
    }>;
    importFile(id: string, name: string, bytes: Buffer, control?: {
        signal?: AbortSignal;
    }): Promise<Material>;
    /** Append only to this work's material source. Original bytes and the work
     * reference are separate storage writes: a failed CAS never overwrites the
     * newer work, but may leave private unreferenced bytes for later recovery. */
    addFile(id: string, input: unknown, bytes: Buffer, control?: {
        signal?: AbortSignal;
    }): Promise<Creation>;
    /** Only the explicitly injected Host reader may fetch this URL. No browser
     * login, legacy background job or implicit model analysis is started here. */
    addUrl(id: string, input: unknown, control?: {
        signal?: AbortSignal;
    }): Promise<Creation>;
    attachment(id: string, attachmentId: string, preview: boolean): Promise<{
        format: import("../domain/creation-material-extraction.ts").AttachmentFormat;
        html: string;
        bytes: Buffer;
        name: string;
    }>;
    create(input: unknown): Promise<Creation>;
    save(id: string, input: unknown): Promise<Creation>;
    startMaterial(id: string, input: unknown): Promise<Creation>;
    private executeMaterial;
    saveAccount(input: unknown): Promise<{
        id: string;
        name: string;
        audience: string;
        voice: string;
        boundaries: string;
        profile?: {
            experience: string;
            opinions: string;
            value: string;
            curiosity: string;
            ai: string;
            style: string;
            publishing: string;
        } | undefined;
    }>;
    savePreferences(id: string, input: unknown): Promise<Creation>;
    confirm(id: string, input: unknown): Promise<Creation>;
    start(id: string, input: unknown, batch?: Creation): Promise<Creation>;
    /** A trusted SDK/Host invocation stays active through generation and commit.
     * The store and model ports retain the caller's authority; this method never
     * creates permission or detaches a controlled job after returning.
     */
    run(id: string, input: unknown, control?: {
        signal?: AbortSignal;
        feedbackOrigin?: "AUTHOR" | "ASSISTANT";
    }): Promise<Creation>;
    private prepareOperation;
    private lockInput;
    private execute;
    private applyWorkspaceDraft;
    undoAppliedUpdate(id: string, input: unknown): Promise<Creation>;
    adoptPlan(id: string, input: unknown): Promise<Creation>;
    undoPreference(id: string, input: unknown): Promise<Creation>;
    private snapshotPlan;
    restorePlan(id: string, input: unknown): Promise<Creation>;
    adoptVersion(id: string, input: unknown): Promise<Creation>;
    private snapshotWorking;
    importWorking(id: string, input: unknown): Promise<Creation>;
    approve(id: string, input: unknown): Promise<Creation>;
    producePlatforms(id: string, input: unknown): Promise<Creation>;
    private renderWorkingAssets;
    preview(id: string, value: unknown): Promise<{
        id: string;
        revision: number;
        artifact: "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT";
        output: {
            title: string;
            body: string;
            cards: {
                title: string;
                body: string;
            }[];
        };
        byline: string;
        versionId: string | null;
        approval: {
            id: string;
            at: string;
            versionId: string;
            baseHash: string;
            outputHash: string;
            assetHashes: string[];
        } | null;
        renderer: string;
        assets: string[];
    }>;
    export(id: string, versionId: string): Promise<{
        title: string;
        version: Version;
        approval: {
            id: string;
            at: string;
            versionId: string;
            baseHash: string;
            outputHash: string;
            assetHashes: string[];
        };
        account: {
            id: string;
            name: string;
            audience: string;
            voice: string;
            boundaries: string;
            profile?: {
                experience: string;
                opinions: string;
                value: string;
                curiosity: string;
                ai: string;
                style: string;
                publishing: string;
            } | undefined;
        } | null;
        target: {
            platform: string;
            carrier: string;
            account: string;
        };
        renderer: string;
    }>;
}
