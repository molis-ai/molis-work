import type { EvidenceResearchRun } from "../application/evidence-acquisition.ts";
export interface ResearchRunStore {
    load(researchRunId: string): Promise<EvidenceResearchRun | undefined>;
    save(run: EvidenceResearchRun): Promise<void>;
}
