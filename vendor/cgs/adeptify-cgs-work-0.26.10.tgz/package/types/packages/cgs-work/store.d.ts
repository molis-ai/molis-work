import type { PluginPrivateStorage } from "@molis-ai/molis-work-plugin-sdk";
import { type AttachmentFormat } from '../../src/domain/creation-material-extraction.ts';
import type { CreationState, CreationStore } from "../../src/storage/creation-store.ts";
/** Only receives a Host-bound private store and the current Action's authority.
 * A fresh instance is scoped to each invocation, never retained for background work.
 * Work owns the database and grant checks; CGS owns the value schema and CAS conflict.
 */
export declare class WorkCreationStore implements CreationStore {
    private readonly storage;
    private readonly beforeEffect;
    private readonly signal?;
    private readonly assertCurrent?;
    constructor(storage: PluginPrivateStorage, beforeEffect: () => Promise<void>, signal?: AbortSignal, assertCurrent?: () => void);
    read(): Promise<CreationState>;
    change<T>(change: (state: CreationState) => T): Promise<T>;
    writeAttachment(bytes: Buffer, preview: {
        format: AttachmentFormat;
        html: string;
    }): Promise<string>;
    readAttachment(id: string, preview?: boolean): Promise<{
        format: "PDF" | "DOCX" | "TEXT" | "IMAGE" | "AUDIO" | "VIDEO";
        html: string;
        bytes: Buffer<ArrayBuffer>;
    }>;
}
