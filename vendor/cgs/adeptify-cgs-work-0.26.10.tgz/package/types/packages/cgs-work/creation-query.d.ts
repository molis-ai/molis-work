import type { DiscussionResult, GenerationResult, Operation, PlanResult } from "../../src/domain/creation.ts";
export interface CreationQueryResult {
    value: unknown;
    candidate?: PlanResult | GenerationResult;
    metadata?: Pick<DiscussionResult, "nextSteps" | "preferenceChange" | "researchNeed">;
}
/** Pure validation/read queries, NOT aliases for persisted author commands.
 * Every invocation computes in a fresh projection and returns its result. No
 * shared candidate, work, preference, or approval changes here. The waiting
 * author-requested generation consumes the result only after the run succeeds.
 */
export declare function creationQueries(source: Operation, references: ReadonlyMap<string, unknown>): {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
    run(input: unknown): Promise<CreationQueryResult>;
}[];
