import type { createCgsWorkPlugin } from './types/packages/cgs-work/index.js';
import type {AgentPromptText,AgentSkillDefinition} from '@molis-ai/molis-work-contracts/platform/plugin-agent';
export declare const createCgsRuntimePlugin: typeof createCgsWorkPlugin;
export declare const cgsManifest: ReturnType<typeof createCgsWorkPlugin>['manifest'];
export declare const cgsPrompts: readonly AgentPromptText[];
export declare const cgsMethods: readonly AgentSkillDefinition[];
