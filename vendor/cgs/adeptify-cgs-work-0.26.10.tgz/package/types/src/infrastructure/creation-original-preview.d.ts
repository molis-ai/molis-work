import { type AttachmentFormat } from '../domain/creation-material-extraction.ts';
/** Stored preview HTML is still untrusted, including legacy imports. Rendering
 * is local and passive: no scripts, forms, external images or active links. */
export declare function makeOriginalPreview(file: {
    name: string;
    format: AttachmentFormat;
    bytes: Buffer;
    html: string;
}, { page, signal }?: {
    page?: number;
    signal?: AbortSignal;
}): Promise<{
    page: number;
    totalPages: number;
    width: number;
    height: number;
    pngBase64: string;
    format: "PDF";
    filename: string;
    text?: undefined;
    mime?: undefined;
    base64?: undefined;
    html?: undefined;
} | {
    format: "TEXT";
    filename: string;
    text: string;
    mime?: undefined;
    base64?: undefined;
    html?: undefined;
} | {
    format: "IMAGE" | "AUDIO" | "VIDEO";
    filename: string;
    mime: string;
    base64: string;
    text?: undefined;
    html?: undefined;
} | {
    format: "DOCX";
    filename: string;
    html: string;
    text?: undefined;
    mime?: undefined;
    base64?: undefined;
}>;
