import { type SearchTransportProfileInput } from "@adeptify/search-evidence-layer/host/node";
import type { EvidenceAcquisitionPort } from "../application/evidence-acquisition.ts";
export declare const ANYSEARCH_PUBLIC_TRANSPORT_PROFILE: SearchTransportProfileInput;
export declare function createLiveSelPublicSearch(input?: {
    readonly apiKey?: string;
    readonly transportMode?: "PINNED" | "PROXY_COMPATIBLE";
    readonly fetchFn?: typeof fetch;
    readonly allowedRssFeedUrls?: readonly string[];
}): {
    readonly acquisition: EvidenceAcquisitionPort;
    shutdown(): Promise<void>;
};
