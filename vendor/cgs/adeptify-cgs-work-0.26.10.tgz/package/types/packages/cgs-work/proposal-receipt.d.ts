import { type Creation } from '../../src/domain/creation.ts';
/** The outer assistant needs this request's result, not the author's archive.
 * Never spread a Work/Operation/Version here: they contain historical sources,
 * excluded originals, account snapshots and provider diagnostics. */
export declare function proposalReceipt(work: Creation, requestId: string, executing?: readonly string[]): {
    work: {
        id: string;
        revision: number;
    };
    request: {
        interrupted?: boolean | undefined;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT" | undefined;
        startedAt: string;
        finishedAt: string | null;
        outputConstraints?: {
            bodyMinCharacters?: number | undefined;
            bodyMaxCharacters?: number | undefined;
            cardCount?: number | undefined;
            cardMaxCharacters?: number | undefined;
        } | undefined;
        id: string;
        status: "RUNNING" | "SUCCEEDED" | "FAILED";
        applyStatus: "NONE" | "APPLIED" | "SUGGESTED" | "DEFERRED" | undefined;
    };
    candidate: {
        versionId: string;
        artifact: "MANUSCRIPT" | "XIAOHONGSHU" | "WECHAT" | "JIKE" | "ZHIHU" | "X" | "DOUYIN_ARTICLE" | "REDDIT" | undefined;
        hash: string;
        output: {
            title: string;
            body: string;
            cards: {
                title: string;
                body: string;
            }[];
        };
        validation: {
            measuredLength: boolean;
            authorFacts: string;
            message: string;
        };
        titleCharacters: number;
        titleNonWhitespaceCharacters: number;
        bodyCharacters: number;
        bodyNonWhitespaceCharacters: number;
        cardCharacters: {
            page: number;
            bodyCharacters: number;
            bodyNonWhitespaceCharacters: number;
        }[];
    } | null;
};
