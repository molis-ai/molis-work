import type { CgsWorkFiles } from './files.ts';
/** Device-dependent services, explicitly supplied by trusted Work composition. */
export declare const cgsWorkFiles: CgsWorkFiles;
