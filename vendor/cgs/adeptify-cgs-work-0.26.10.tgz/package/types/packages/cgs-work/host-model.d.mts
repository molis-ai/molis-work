/** Create once per trusted CGS activation. `owner` and model configuration are
 * Host metadata, never business JSON. Availability must be metadata-only.
 * The caller owns the shared service; dispose withdraws only this adapter.
 */
export function createCgsWorkModel({ actions, service, bindHostAgentPrompts, homeDirectory, root, selection, owner, availability }: {
    actions: any;
    service: any;
    bindHostAgentPrompts: any;
    homeDirectory: any;
    root: any;
    selection: any;
    owner: any;
    availability: any;
}): Promise<{
    availability(): any;
    bind(caller: any): {
        readonly available: any;
        label: string;
        assertCurrent(): void;
        method(context: any): Promise<{
            version: string;
            hash: string;
            files: {
                path: string;
                text: any;
            }[];
            model: string;
            provider: string;
        }>;
        editorial(task: any, input: any, control: any): Promise<never>;
        run(operation: any, progress: any, references: Map<any, any> | undefined, hooks: any): Promise<any>;
    };
    dispose(): Promise<void>;
}>;
