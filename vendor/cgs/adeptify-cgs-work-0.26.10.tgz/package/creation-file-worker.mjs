import {createRequire as __cgsRequire} from "node:module"; const require = __cgsRequire(process.execPath);

// src/infrastructure/creation-file-worker.ts
import { parentPort, workerData } from "node:worker_threads";
import { fileURLToPath } from "node:url";
import mammoth from "mammoth";
import sanitizeHtml from "sanitize-html";
import { fromBuffer } from "yauzl";
async function checkArchive(bytes) {
  await new Promise((resolve, reject) => fromBuffer(bytes, { lazyEntries: true }, (error, zip) => {
    if (error || !zip) return reject(new Error("Word \u6587\u4EF6\u5DF2\u635F\u574F\uFF0C\u8BF7\u91CD\u65B0\u4FDD\u5B58\u540E\u518D\u8BD5\u3002"));
    let total = 0, entries = 0;
    zip.on("error", reject);
    zip.on("end", resolve);
    zip.on("entry", (entry) => {
      total += entry.uncompressedSize;
      entries++;
      if (total > 50 * 1024 * 1024 || entries > 3e3) {
        zip.close();
        reject(new Error("Word \u89E3\u538B\u540E\u7684\u5185\u5BB9\u8FC7\u5927\uFF0C\u8BF7\u7CBE\u7B80\u56FE\u7247\u6216\u62C6\u5206\u6587\u4EF6\u540E\u518D\u8BD5\u3002"));
      } else zip.readEntry();
    });
    zip.readEntry();
  }));
}
try {
  const { format } = workerData;
  const bytes = Buffer.from(workerData.bytes);
  let text = "", html = "", pages, needsOcr = false;
  if (format === "PDF") {
    const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
    const task = getDocument({
      data: new Uint8Array(bytes),
      useSystemFonts: true,
      cMapUrl: fileURLToPath(new URL("./cmaps/", import.meta.resolve("pdfjs-dist/package.json"))),
      cMapPacked: true,
      standardFontDataUrl: fileURLToPath(new URL("./standard_fonts/", import.meta.resolve("pdfjs-dist/package.json")))
    });
    const pdf = await task.promise;
    try {
      pages = pdf.numPages;
      if (pages > 200) throw new Error("PDF \u8D85\u8FC7 200 \u9875\uFF0C\u8BF7\u9009\u53D6\u76F8\u5173\u7AE0\u8282\u540E\u52A0\u5165\u3002");
      for (let p = 1; p <= pages; p++) {
        const page = await pdf.getPage(p);
        const content = await page.getTextContent();
        const pageText = content.items.map((item) => "str" in item ? item.str + (item.hasEOL ? "\n" : " ") : "").join("").trim();
        if (!pageText) needsOcr = true;
        text += pageText + "\n\n";
        page.cleanup();
        if (text.length > 1e5) throw new Error("\u6587\u4EF6\u6B63\u6587\u8D85\u8FC7 10 \u4E07\u5B57\u7B26\uFF0C\u8BF7\u9009\u53D6\u76F8\u5173\u7AE0\u8282\u540E\u52A0\u5165\u3002");
      }
    } finally {
      await task.destroy();
    }
  } else {
    await checkArchive(bytes);
    text = (await mammoth.extractRawText({ buffer: bytes })).value;
    const result = await mammoth.convertToHtml({ buffer: bytes }, {
      externalFileAccess: false,
      includeEmbeddedStyleMap: false,
      styleMap: ["p[style-name='Title'] => h1:fresh"],
      convertImage: mammoth.images.imgElement(async (image) => ({ src: /^(image\/(png|jpeg|gif|webp))$/.test(image.contentType) ? `data:${image.contentType};base64,${await image.readAsBase64String()}` : "" }))
    });
    html = sanitizeHtml(result.value, {
      allowedTags: ["p", "h1", "h2", "h3", "h4", "h5", "h6", "strong", "em", "u", "s", "sup", "sub", "br", "hr", "ul", "ol", "li", "blockquote", "table", "thead", "tbody", "tr", "td", "th", "a", "img"],
      allowedAttributes: { a: ["href", "target", "rel"], img: ["src", "alt"], td: ["colspan", "rowspan"], th: ["colspan", "rowspan"] },
      allowedSchemes: ["https", "http", "mailto"],
      allowedSchemesByTag: { img: ["data"] },
      allowProtocolRelative: false,
      transformTags: { a: sanitizeHtml.simpleTransform("a", { target: "_blank", rel: "noopener noreferrer" }) },
      exclusiveFilter: (frame) => frame.tag === "img" && !/^data:image\/(png|jpeg|gif|webp);base64,/.test(frame.attribs.src || "")
    });
    if (html.length > 15e6) throw new Error("Word \u4E2D\u56FE\u7247\u8F83\u591A\uFF0C\u8BF7\u7CBE\u7B80\u56FE\u7247\u540E\u518D\u52A0\u5165\u3002");
  }
  if (text.length > 1e5) throw new Error("\u6587\u4EF6\u6B63\u6587\u8D85\u8FC7 10 \u4E07\u5B57\u7B26\uFF0C\u8BF7\u9009\u53D6\u76F8\u5173\u7AE0\u8282\u540E\u52A0\u5165\u3002");
  parentPort.postMessage({ format, text: text.trim(), html, ...pages ? { pages, needsOcr } : {} });
} catch (error) {
  const message = error instanceof Error && error.name === "PasswordException" ? "PDF \u5DF2\u52A0\u5BC6\uFF0C\u8BF7\u89E3\u9501\u540E\u91CD\u65B0\u52A0\u5165\u3002" : error instanceof Error && /[\u4e00-\u9fff]/.test(error.message) ? error.message : "\u6587\u4EF6\u65E0\u6CD5\u89E3\u6790\uFF0C\u53EF\u80FD\u5DF2\u635F\u574F\u6216\u52A0\u5BC6\u3002\u8BF7\u91CD\u65B0\u4FDD\u5B58\u540E\u518D\u8BD5\u3002";
  parentPort.postMessage({ error: message });
}
