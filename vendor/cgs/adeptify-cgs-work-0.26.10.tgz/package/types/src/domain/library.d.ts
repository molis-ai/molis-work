import { z } from "zod";
import type { topicSourceSchema } from "./topics.ts";
export declare const libraryHashSchema: z.ZodString;
export declare const libraryUsageSchema: z.ZodEnum<{
    BOUNDED: "BOUNDED";
    RESEARCH_ONLY: "RESEARCH_ONLY";
    DEFER: "DEFER";
}>;
export declare const libraryPackageSchema: z.ZodObject<{
    id: z.ZodString;
    sourceId: z.ZodString;
    path: z.ZodString;
    usage: z.ZodEnum<{
        BOUNDED: "BOUNDED";
        RESEARCH_ONLY: "RESEARCH_ONLY";
        DEFER: "DEFER";
    }>;
    revisionOf: z.ZodNullable<z.ZodString>;
    manifestHash: z.ZodString;
    reportHash: z.ZodString;
    researchHash: z.ZodString;
    guideHash: z.ZodString;
    guidePath: z.ZodString;
    methodId: z.ZodString;
    question: z.ZodString;
    limitations: z.ZodArray<z.ZodString>;
    researchCompletedAt: z.ZodString;
    publishedAt: z.ZodString;
    url: z.ZodURL;
}, z.core.$strict>;
export declare const librarySnapshotSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<1>;
    sourcesHash: z.ZodString;
    catalogHash: z.ZodString;
    packages: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        sourceId: z.ZodString;
        path: z.ZodString;
        usage: z.ZodEnum<{
            BOUNDED: "BOUNDED";
            RESEARCH_ONLY: "RESEARCH_ONLY";
            DEFER: "DEFER";
        }>;
        revisionOf: z.ZodNullable<z.ZodString>;
        manifestHash: z.ZodString;
        reportHash: z.ZodString;
        researchHash: z.ZodString;
        guideHash: z.ZodString;
        guidePath: z.ZodString;
        methodId: z.ZodString;
        question: z.ZodString;
        limitations: z.ZodArray<z.ZodString>;
        researchCompletedAt: z.ZodString;
        publishedAt: z.ZodString;
        url: z.ZodURL;
    }, z.core.$strict>>;
    excluded: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        sourceId: z.ZodString;
        reason: z.ZodString;
    }, z.core.$strict>>;
    revisions: z.ZodDefault<z.ZodArray<z.ZodObject<{
        sourceId: z.ZodString;
        from: z.ZodString;
        to: z.ZodString;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type LibraryPackage = z.infer<typeof libraryPackageSchema>;
export type LibrarySnapshot = z.infer<typeof librarySnapshotSchema>;
export type LibraryEvidence = {
    id: string;
    recordId: string;
    originKey: string;
    reportedReadScope: string;
    reportedPublishedAt: string | null;
    source: z.infer<typeof topicSourceSchema>;
};
export type LibraryFinding = {
    id: string;
    originalId: string;
    text: string;
    evidenceIds: string[];
    unresolvedReferences: string[];
};
export type LibraryMaterial = {
    package: LibraryPackage;
    report: string;
    guide: string;
    limitations: string[];
    evidence: LibraryEvidence[];
    findings: LibraryFinding[];
};
