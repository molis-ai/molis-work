export type ProviderName = "minimax" | "openai" | "xai";
export type ApiFormat = "anthropic-messages" | "openai-chat-completions" | "openai-responses";
export type ModelTool = {
    name: string;
    description: string;
    parameters: Record<string, unknown>;
};
export type ModelMessage = {
    role: "user" | "assistant";
    content: string;
} | {
    role: "native";
    items: Record<string, any>[];
} | {
    role: "tool";
    results: {
        id: string;
        output: unknown;
    }[];
};
export type ModelReply = {
    text: string;
    calls: {
        id: string;
        name: string;
        arguments: unknown;
    }[];
    native: Record<string, any>[];
};
export type ProviderOptions = {
    provider: string;
    name?: string;
    format?: ApiFormat;
    apiKey: string;
    model: string;
    baseUrl?: string;
    maxOutputTokens?: number;
    reasoningEffort?: string;
    fetchFn?: typeof fetch;
};
export type WireRequest = {
    format: ApiFormat;
    url: string;
    headers: Record<string, string>;
};
export declare function wireRequest(options: Pick<ProviderOptions, "provider" | "format" | "baseUrl" | "apiKey">): WireRequest;
export declare class CreationProvider {
    readonly options: ProviderOptions;
    constructor(options: ProviderOptions);
    get available(): boolean;
    get label(): string;
    complete(system: string, messages: ModelMessage[], tools: ModelTool[], choice?: "auto" | {
        name: string;
    }, signal?: AbortSignal): Promise<ModelReply>;
}
