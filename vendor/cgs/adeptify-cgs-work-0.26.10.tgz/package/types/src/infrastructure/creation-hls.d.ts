export declare function downloadHls(url: URL, initial: string, directory: string, fetchFn: typeof fetch, progress?: (message: string) => Promise<void>): Promise<string>;
