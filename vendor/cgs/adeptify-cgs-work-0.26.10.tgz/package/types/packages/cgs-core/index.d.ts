import { CreationWorkspace } from "../../src/application/creation-workspace.ts";
import type { CreationModel } from "../../src/application/creation-model.ts";
import type { CreationStore } from "../../src/storage/creation-store.ts";
import type { CreationExecutionScope } from "../../src/application/creation-execution.ts";
import type { CreationMaterialPorts } from '../../src/application/creation-material-ports.ts';
export type { CreationModel } from "../../src/application/creation-model.ts";
export type { CreationStore, CreationState } from "../../src/storage/creation-store.ts";
export { createCreationExecutionScope as createCgsExecutionScope } from "../../src/application/creation-execution.ts";
export type { CreationExecutionScope } from "../../src/application/creation-execution.ts";
export type CgsCore = CreationWorkspace;
export { operationSchema as creationOperationSchema, CreationStoppedAfterStartError } from "../../src/application/creation-workspace.ts";
export { prepareCreationTurn, type CreationTurnOptions } from "../../src/application/creation-turn.ts";
export type CgsCoreOptions = {
    store: CreationStore;
    model: CreationModel;
    readMaterial?: ConstructorParameters<typeof CreationWorkspace>[2];
    research?: ConstructorParameters<typeof CreationWorkspace>[3];
    executionScope?: CreationExecutionScope;
    materials?: CreationMaterialPorts;
};
/** Shared in-process business entry. The trusted caller supplies scoped ports;
 * this does not start a Host/server, acquire credentials, recover jobs, or grant
 * permission to a remote caller. Public Host actions must enforce their own
 * trusted caller, cancellation and before-effect checks. */
export declare function createCgsCore(options: CgsCoreOptions): CgsCore;
