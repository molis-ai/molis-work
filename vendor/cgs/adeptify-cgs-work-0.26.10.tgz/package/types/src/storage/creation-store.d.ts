import type { BackgroundInterview } from "../domain/background-interview.ts";
import type { Account, Creation } from "../domain/creation.ts";
import type { MethodCandidate } from "../domain/creation-learning.ts";
import type { SavedMaterial } from "../domain/material-library.ts";
import type { AttachmentFormat } from '../domain/creation-material-extraction.ts';
export type CreationState = {
    schemaVersion: 1;
    accounts: Account[];
    backgroundInterviews?: BackgroundInterview[];
    creations: Creation[];
    methodCandidates?: MethodCandidate[];
    materials?: SavedMaterial[];
    topicRequests?: {
        id: string;
        fingerprint: string;
        creationId: string;
    }[];
};
/** A store already bound to its trusted owner. Business input cannot choose
 * another owner's storage. change must serialize/atomically reject conflicts;
 * it must not replay a callback after an unknown commit result. */
export interface CreationStore {
    read(): Promise<CreationState>;
    change<T>(change: (state: CreationState) => T): Promise<T>;
    writeAttachment(bytes: Buffer, preview: {
        format: AttachmentFormat;
        html: string;
    }): Promise<string>;
    readAttachment(id: string, preview?: boolean): Promise<{
        format: AttachmentFormat;
        html: string;
        bytes: Buffer;
    }>;
}
