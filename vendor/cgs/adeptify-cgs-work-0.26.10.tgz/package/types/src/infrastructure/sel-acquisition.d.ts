import type { SearchRuntime } from "@adeptify/search-evidence-layer";
import type { EvidenceAcquisitionPort } from "../application/evidence-acquisition.ts";
export declare function createSelEvidenceAcquisitionPort(input: {
    readonly runtime: SearchRuntime;
    readonly readContent: (contentRef: string) => Promise<string>;
}): EvidenceAcquisitionPort;
