import { type Plan, type PlanComparison, type DiscussionResult, type MaterialContext, type MaterialInsight, type GenerationResult, type Method, type Operation, type PlanResult } from "../domain/creation.ts";
export { preserveEditScope } from "./creation-apply.ts";
import { z } from "zod";
import { type ProviderOptions } from "../infrastructure/creation-provider.ts";
import type { Creation } from "../domain/creation.ts";
import type { RuntimeDescriptor } from "../domain/creation-runtime.ts";
import type { ModelExecution } from "../domain/creation-model-receipt.ts";
export { validateDraft } from "./creation-tools.ts";
export declare function materialPassages(text: string): {
    id: number;
    text: string;
}[];
export declare function parsePlanComparisonText(raw: string): {
    reason: string;
    direction: "SAME_DIRECTION" | "NEW_ANGLE" | "OPPOSITE" | "UNCERTAIN";
    summary: string;
    currentView: string;
    proposedView: string;
    tradeoff: string;
    beforeEvidenceId: number;
    afterEvidenceId: number;
};
export declare function validatePlanComparison(value: unknown, before: Plan, after: Plan): PlanComparison;
export declare class CreationModelOutputError extends Error {
    providerOutput: string;
    details: string;
    constructor(providerOutput: string, details: string);
}
export declare class CreationCandidateReceiptError extends Error {
    candidate: GenerationResult;
    constructor(candidate: GenerationResult, cause: unknown);
}
export declare function parseCreationModelResult(raw: string, kind: Operation["kind"]): PlanResult | GenerationResult;
export type ModelRunHooks = {
    signal?: AbortSignal;
    onExecution?: (execution: ModelExecution) => Promise<void>;
    onSession?: (session: {
        engine: "codex" | "grok";
        threadId?: string;
        sessionId?: string;
        stale?: boolean;
        snapshotHash?: string;
    }) => Promise<void>;
};
export interface CreationModel {
    editorial?(task: "RESEARCH" | "LEARN", input: unknown, context?: {
        signal?: AbortSignal;
    }): Promise<unknown>;
    available: boolean;
    label?: string;
    unavailableMessage?: string;
    method(context?: {
        work?: Pick<Creation, "id" | "runtime">;
    }): Promise<Method>;
    comparePlans?(input: {
        before: Plan;
        after: Plan;
        request: string;
    }, context?: {
        work?: Pick<Creation, "id" | "runtime">;
        signal?: AbortSignal;
    }): Promise<PlanComparison>;
    analyzeMaterial?(input: MaterialContext, context?: {
        work?: Pick<Creation, "id" | "runtime">;
        signal?: AbortSignal;
    }): Promise<MaterialInsight>;
    run(operation: Operation, progress?: (message: string) => Promise<void>, references?: ReadonlyMap<string, unknown>, hooks?: ModelRunHooks): Promise<PlanResult | GenerationResult | DiscussionResult>;
    resolve?(work: Pick<Creation, "id" | "runtime">): CreationModel;
    listRuntimes?(): Promise<RuntimeDescriptor[]>;
    refreshRuntimes?(): Promise<RuntimeDescriptor[]>;
    setExecutable?(adapter: "codex" | "grok", command: string): Promise<RuntimeDescriptor[]>;
}
export declare class CreationAgentModel implements CreationModel {
    private root;
    private provider;
    get available(): boolean;
    get label(): string;
    constructor(root: string, options: ProviderOptions);
    method(): Promise<Method>;
    private requestRaw;
    comparePlans(input: {
        before: Plan;
        after: Plan;
        request: string;
    }): Promise<PlanComparison>;
    analyzeMaterial(input: MaterialContext): Promise<MaterialInsight>;
    editorial(task: "RESEARCH" | "LEARN", input: unknown, context?: {
        signal?: AbortSignal;
    }): Promise<any>;
    run(operation: Operation, progress?: (message: string) => Promise<void>, references?: ReadonlyMap<string, unknown>, hooks?: ModelRunHooks): Promise<PlanResult | GenerationResult | DiscussionResult>;
    private edit;
}
export type StructuredTask = true | "REVIEW" | "COMPARE_PLAN" | "RESEARCH" | "LEARN";
export declare function structuredTool(task: StructuredTask, input?: unknown): {
    name: string;
    description: string;
    parameters: z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
        change: z.ZodNullable<z.ZodObject<{
            instruction: z.ZodString;
            rationale: z.ZodString;
            applicability: z.ZodString;
            evidence: z.ZodArray<z.ZodObject<{
                operationId: z.ZodString;
                quote: z.ZodString;
            }, z.core.$strict>>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    parse: (value: unknown) => {
        change: {
            instruction: string;
            rationale: string;
            applicability: string;
            evidence: {
                operationId: string;
                quote: string;
            }[];
        } | null;
    };
} | {
    name: string;
    description: string;
    parameters: z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
        verdict: z.ZodEnum<{
            SUPPORTED: "SUPPORTED";
            CONTRADICTED: "CONTRADICTED";
            UNRESOLVED: "UNRESOLVED";
        }>;
        summary: z.ZodString;
        followup: z.ZodNullable<z.ZodObject<{
            query: z.ZodString;
            reason: z.ZodString;
        }, z.core.$strict>>;
        evidence: z.ZodArray<z.ZodObject<{
            passageId: z.ZodNumber;
            claim: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    parse: (value: unknown) => {
        verdict: "SUPPORTED" | "CONTRADICTED" | "UNRESOLVED";
        summary: string;
        evidence: {
            sourceId: string;
            quote: string;
            claim: string;
        }[];
        followup: {
            query: string;
            reason: string;
        } | null;
    };
} | {
    name: string;
    description: string;
    parameters: z.core.ZodStandardJSONSchemaPayload<z.ZodObject<{
        reason: z.ZodString;
        direction: z.ZodEnum<{
            SAME_DIRECTION: "SAME_DIRECTION";
            NEW_ANGLE: "NEW_ANGLE";
            OPPOSITE: "OPPOSITE";
            UNCERTAIN: "UNCERTAIN";
        }>;
        summary: z.ZodString;
        currentView: z.ZodString;
        proposedView: z.ZodString;
        tradeoff: z.ZodString;
        beforeEvidenceId: z.ZodNumber;
        afterEvidenceId: z.ZodNumber;
    }, z.core.$strict> | z.ZodObject<{
        issues: z.ZodArray<z.ZodObject<{
            evidence: z.ZodString;
            problem: z.ZodString;
            suggestion: z.ZodString;
            needsAuthor: z.ZodBoolean;
            passageId: z.ZodNumber;
        }, z.core.$strict>>;
    }, z.core.$strict> | z.ZodObject<{
        summary: z.ZodString;
        relation: z.ZodString;
        next: z.ZodString;
        nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
            label: z.ZodString;
            reason: z.ZodString;
            prompt: z.ZodString;
        }, z.core.$strict>>>;
        evidenceId: z.ZodNumber;
    }, z.core.$strict>>;
    parse: (value: unknown) => {
        reason: string;
        direction: "SAME_DIRECTION" | "NEW_ANGLE" | "OPPOSITE" | "UNCERTAIN";
        summary: string;
        currentView: string;
        proposedView: string;
        tradeoff: string;
        beforeEvidenceId: number;
        afterEvidenceId: number;
    } | {
        issues: {
            evidence: string;
            problem: string;
            suggestion: string;
            needsAuthor: boolean;
            passageId: number;
        }[];
    } | {
        summary: string;
        relation: string;
        next: string;
        evidenceId: number;
        nextSteps?: {
            label: string;
            reason: string;
            prompt: string;
        }[] | undefined;
    };
};
export declare class CreationAnalysis {
    private root;
    private requestRaw;
    constructor(root: string, requestRaw: (system: string, input: unknown, task: StructuredTask) => Promise<string>);
    comparePlans(input: {
        before: Plan;
        after: Plan;
        request: string;
    }): Promise<PlanComparison>;
    analyzeMaterial(input: MaterialContext): Promise<MaterialInsight>;
    edit(operation: Operation, initial: GenerationResult, progress?: (message: string) => Promise<void>): Promise<GenerationResult>;
}
export declare function claimsCompletedChange(text: string): boolean;
export declare class MiniMaxCreationModel extends CreationAgentModel {
    constructor(root: string, apiKey: string, model?: string, baseUrl?: string, fetchFn?: typeof fetch);
}
export declare function configuredCreationProviderOptions(env?: NodeJS.ProcessEnv, fetchFn?: typeof fetch): ProviderOptions;
export declare function configuredCreationModel(root: string, env?: NodeJS.ProcessEnv, fetchFn?: typeof fetch): CreationAgentModel;
