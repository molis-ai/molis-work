import { z } from 'zod';
export declare const attachmentFormatSchema: z.ZodEnum<{
    PDF: "PDF";
    DOCX: "DOCX";
    TEXT: "TEXT";
    IMAGE: "IMAGE";
    AUDIO: "AUDIO";
    VIDEO: "VIDEO";
}>;
export type AttachmentFormat = z.infer<typeof attachmentFormatSchema>;
export declare const materialExtractionSchema: z.ZodObject<{
    extractor: z.ZodString;
    coverage: z.ZodObject<{
        status: z.ZodEnum<{
            sufficient: "sufficient";
            partial: "partial";
            insufficient: "insufficient";
        }>;
        truncated: z.ZodOptional<z.ZodBoolean>;
        processed_pages: z.ZodNumber;
        total_pages: z.ZodNumber;
        issues: z.ZodArray<z.ZodString>;
    }, z.core.$strict>;
    locations: z.ZodArray<z.ZodObject<{
        page: z.ZodOptional<z.ZodNumber>;
        start_seconds: z.ZodOptional<z.ZodNumber>;
        end_seconds: z.ZodOptional<z.ZodNumber>;
        text: z.ZodString;
    }, z.core.$strict>>;
    duration_seconds: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export type MaterialExtractionRecord = z.infer<typeof materialExtractionSchema>;
export declare function materialMime(format: AttachmentFormat, name: string): string;
