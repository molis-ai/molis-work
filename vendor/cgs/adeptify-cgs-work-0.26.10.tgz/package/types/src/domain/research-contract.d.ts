import { z } from "zod";
import type { SearchIntentExecutionBudgetV1, SearchIntentSourcePolicyV1, SearchIntentTaskProfileV1 } from "@adeptify/search-evidence-layer/intent";
export declare const primaryObjectiveSchema: z.ZodEnum<{
    REACH: "REACH";
    VALUE: "VALUE";
    RELATIONSHIP: "RELATIONSHIP";
}>;
export declare const researchDimensionSchema: z.ZodEnum<{
    DEMAND: "DEMAND";
    SUPPLY_GAP: "SUPPLY_GAP";
    ATTENTION: "ATTENTION";
    TIMING: "TIMING";
    DISTRIBUTION_FIT: "DISTRIBUTION_FIT";
    EXECUTION_READINESS: "EXECUTION_READINESS";
    EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
    LONG_TERM_RELEVANCE: "LONG_TERM_RELEVANCE";
    AUDIENCE_RELEVANCE: "AUDIENCE_RELEVANCE";
    CREDIBILITY_FIT: "CREDIBILITY_FIT";
    COMMUNITY_RELEVANCE: "COMMUNITY_RELEVANCE";
    CONTINUATION_SPACE: "CONTINUATION_SPACE";
}>;
export declare const researchContractSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<"CGSResearchContractV1">;
    contractVersion: z.ZodString;
    supportedEntryModes: z.ZodArray<z.ZodEnum<{
        OPEN_DISCOVERY: "OPEN_DISCOVERY";
        EXPLICIT_TOPIC: "EXPLICIT_TOPIC";
    }>>;
    objectivePolicies: z.ZodArray<z.ZodObject<{
        primaryObjective: z.ZodEnum<{
            REACH: "REACH";
            VALUE: "VALUE";
            RELATIONSHIP: "RELATIONSHIP";
        }>;
        primaryDimensions: z.ZodArray<z.ZodEnum<{
            DEMAND: "DEMAND";
            SUPPLY_GAP: "SUPPLY_GAP";
            ATTENTION: "ATTENTION";
            TIMING: "TIMING";
            DISTRIBUTION_FIT: "DISTRIBUTION_FIT";
            EXECUTION_READINESS: "EXECUTION_READINESS";
            EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
            LONG_TERM_RELEVANCE: "LONG_TERM_RELEVANCE";
            AUDIENCE_RELEVANCE: "AUDIENCE_RELEVANCE";
            CREDIBILITY_FIT: "CREDIBILITY_FIT";
            COMMUNITY_RELEVANCE: "COMMUNITY_RELEVANCE";
            CONTINUATION_SPACE: "CONTINUATION_SPACE";
        }>>;
        amplifiers: z.ZodArray<z.ZodEnum<{
            HOTSPOT: "HOTSPOT";
            AI_KOL_ATTENTION: "AI_KOL_ATTENTION";
        }>>;
        supplySaturationRule: z.ZodEnum<{
            PRESSURE_NOT_VETO: "PRESSURE_NOT_VETO";
            REQUIRES_DIFFERENTIATION: "REQUIRES_DIFFERENTIATION";
            CONTEXT_NOT_VETO: "CONTEXT_NOT_VETO";
        }>;
        decisionQuestion: z.ZodString;
    }, z.core.$strict>>;
    sourceRules: z.ZodObject<{
        permittedInputKinds: z.ZodArray<z.ZodEnum<{
            SEARCH: "SEARCH";
            PUBLIC_WEB: "PUBLIC_WEB";
            RSS: "RSS";
            AUTHORIZED_LINK: "AUTHORIZED_LINK";
            AUTHORIZED_EXPORT: "AUTHORIZED_EXPORT";
            AI_KOL_LIST: "AI_KOL_LIST";
            AI_KOL_SKILL: "AI_KOL_SKILL";
        }>>;
        unavailableSourceBehavior: z.ZodLiteral<"MARK_COVERAGE_GAP">;
        externalProviderDependency: z.ZodLiteral<"OPTIONAL_AND_REPLACEABLE">;
        providerFailureBehavior: z.ZodLiteral<"CONTINUE_WITH_PROVIDER_GAP">;
        directDemandEvidenceRule: z.ZodLiteral<"PRIMARY_USER_EXPRESSION_REQUIRED_FOR_STRONG_CLAIM">;
        sameSourceFamilyRule: z.ZodLiteral<"COUNT_ONCE">;
        aiKolRepostRule: z.ZodLiteral<"SAME_ORIGINAL_STATEMENT_COUNTS_ONCE">;
        forbiddenBehaviors: z.ZodArray<z.ZodEnum<{
            LOGIN_BYPASS: "LOGIN_BYPASS";
            CLAIM_FULL_PLATFORM_COVERAGE: "CLAIM_FULL_PLATFORM_COVERAGE";
            INVENT_MISSING_METRICS: "INVENT_MISSING_METRICS";
        }>>;
    }, z.core.$strict>;
    decisionBoundary: z.ZodObject<{
        systemMay: z.ZodArray<z.ZodEnum<{
            RESEARCH: "RESEARCH";
            ANALYZE: "ANALYZE";
            PROPOSE_CONTENT_BET: "PROPOSE_CONTENT_BET";
        }>>;
        ownerMust: z.ZodArray<z.ZodEnum<{
            DEFER: "DEFER";
            REJECT: "REJECT";
            SELECT: "SELECT";
            APPROVE_PUBLICATION: "APPROVE_PUBLICATION";
        }>>;
    }, z.core.$strict>;
}, z.core.$strict>;
export type ResearchContract = z.infer<typeof researchContractSchema>;
export declare function parseResearchContract(input: unknown): ResearchContract;
declare const sourceSelectorSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    kind: z.ZodLiteral<"SEL_CHANNEL">;
    value: z.ZodEnum<{
        repository: "repository";
        web: "web";
        rss: "rss";
        official: "official";
        community: "community";
    }>;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"PROVIDER">;
    value: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"DOMAIN">;
    value: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"URL">;
    value: z.ZodURL;
}, z.core.$strict>, z.ZodObject<{
    kind: z.ZodLiteral<"CGS_INPUT">;
    value: z.ZodEnum<{
        AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
        AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
    }>;
}, z.core.$strict>], "kind">;
type SourceSelector = z.infer<typeof sourceSelectorSchema>;
export declare const cgsSourcePolicySchema: z.ZodObject<{
    required: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"SEL_CHANNEL">;
        value: z.ZodEnum<{
            repository: "repository";
            web: "web";
            rss: "rss";
            official: "official";
            community: "community";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"PROVIDER">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DOMAIN">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"URL">;
        value: z.ZodURL;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"CGS_INPUT">;
        value: z.ZodEnum<{
            AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
            AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
        }>;
    }, z.core.$strict>], "kind">>;
    preferred: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"SEL_CHANNEL">;
        value: z.ZodEnum<{
            repository: "repository";
            web: "web";
            rss: "rss";
            official: "official";
            community: "community";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"PROVIDER">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DOMAIN">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"URL">;
        value: z.ZodURL;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"CGS_INPUT">;
        value: z.ZodEnum<{
            AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
            AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
        }>;
    }, z.core.$strict>], "kind">>;
    allowed: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"SEL_CHANNEL">;
        value: z.ZodEnum<{
            repository: "repository";
            web: "web";
            rss: "rss";
            official: "official";
            community: "community";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"PROVIDER">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DOMAIN">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"URL">;
        value: z.ZodURL;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"CGS_INPUT">;
        value: z.ZodEnum<{
            AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
            AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
        }>;
    }, z.core.$strict>], "kind">>;
    forbidden: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"SEL_CHANNEL">;
        value: z.ZodEnum<{
            repository: "repository";
            web: "web";
            rss: "rss";
            official: "official";
            community: "community";
        }>;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"PROVIDER">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"DOMAIN">;
        value: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"URL">;
        value: z.ZodURL;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"CGS_INPUT">;
        value: z.ZodEnum<{
            AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
            AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
        }>;
    }, z.core.$strict>], "kind">>;
}, z.core.$strict>;
export declare const researchBudgetSchema: z.ZodObject<{
    maxProviderCalls: z.ZodNumber;
    maxFetchExtractCalls: z.ZodNumber;
    maxModelInputTokens: z.ZodNumber;
    maxModelOutputTokens: z.ZodNumber;
    maxMaterials: z.ZodNumber;
    maxBytes: z.ZodNumber;
    maxConcurrency: z.ZodNumber;
    deadlineMs: z.ZodNumber;
    maxMoneyMicros: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const researchStopPolicySchema: z.ZodObject<{
    whenRequirementsMet: z.ZodLiteral<"STOP_COMPLETE">;
    whenBudgetExhausted: z.ZodLiteral<"STOP_PARTIAL">;
    whenDeadlineExceeded: z.ZodLiteral<"STOP_PARTIAL">;
    whenRequiredSourceUnavailable: z.ZodLiteral<"STOP_INSUFFICIENT">;
    whenNoProgress: z.ZodLiteral<"STOP_INSUFFICIENT">;
    whenUserCancelled: z.ZodLiteral<"STOP_CANCELLED">;
    maxGapFillAttempts: z.ZodNumber;
}, z.core.$strict>;
export declare const openDiscoveryBriefSchema: z.ZodObject<{
    briefId: z.ZodString;
    briefVersion: z.ZodString;
    primaryObjective: z.ZodEnum<{
        REACH: "REACH";
        VALUE: "VALUE";
        RELATIONSHIP: "RELATIONSHIP";
    }>;
    decisionContext: z.ZodObject<{
        ownerId: z.ZodString;
        targetAccounts: z.ZodArray<z.ZodObject<{
            platform: z.ZodEnum<{
                XIAOHONGSHU: "XIAOHONGSHU";
                JIKE: "JIKE";
                X: "X";
            }>;
            accountId: z.ZodString;
        }, z.core.$strict>>;
        audienceIntents: z.ZodArray<z.ZodEnum<{
            BEGINNER: "BEGINNER";
            BUILDER: "BUILDER";
        }>>;
    }, z.core.$strict>;
    researchWindow: z.ZodObject<{
        since: z.ZodString;
        until: z.ZodString;
        asOf: z.ZodString;
    }, z.core.$strict>;
    locale: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        dimension: z.ZodEnum<{
            DEMAND: "DEMAND";
            SUPPLY_GAP: "SUPPLY_GAP";
            ATTENTION: "ATTENTION";
            TIMING: "TIMING";
            DISTRIBUTION_FIT: "DISTRIBUTION_FIT";
            EXECUTION_READINESS: "EXECUTION_READINESS";
            EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
            LONG_TERM_RELEVANCE: "LONG_TERM_RELEVANCE";
            AUDIENCE_RELEVANCE: "AUDIENCE_RELEVANCE";
            CREDIBILITY_FIT: "CREDIBILITY_FIT";
            COMMUNITY_RELEVANCE: "COMMUNITY_RELEVANCE";
            CONTINUATION_SPACE: "CONTINUATION_SPACE";
        }>;
        question: z.ZodString;
        required: z.ZodBoolean;
        minimumRelevantMaterials: z.ZodNumber;
        minimumIndependentSourceFamilies: z.ZodNumber;
        primarySource: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        counterevidence: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        freshnessDays: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    sourcePolicy: z.ZodObject<{
        required: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        preferred: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        allowed: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        forbidden: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>;
    budget: z.ZodObject<{
        maxProviderCalls: z.ZodNumber;
        maxFetchExtractCalls: z.ZodNumber;
        maxModelInputTokens: z.ZodNumber;
        maxModelOutputTokens: z.ZodNumber;
        maxMaterials: z.ZodNumber;
        maxBytes: z.ZodNumber;
        maxConcurrency: z.ZodNumber;
        deadlineMs: z.ZodNumber;
        maxMoneyMicros: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    stopPolicy: z.ZodObject<{
        whenRequirementsMet: z.ZodLiteral<"STOP_COMPLETE">;
        whenBudgetExhausted: z.ZodLiteral<"STOP_PARTIAL">;
        whenDeadlineExceeded: z.ZodLiteral<"STOP_PARTIAL">;
        whenRequiredSourceUnavailable: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenNoProgress: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenUserCancelled: z.ZodLiteral<"STOP_CANCELLED">;
        maxGapFillAttempts: z.ZodNumber;
    }, z.core.$strict>;
    schemaVersion: z.ZodLiteral<"OpenDiscoveryBriefV1">;
    entryMode: z.ZodLiteral<"OPEN_DISCOVERY">;
    domainPrompt: z.ZodString;
    signalLenses: z.ZodArray<z.ZodEnum<{
        SUPPLY_GAP: "SUPPLY_GAP";
        HOTSPOT: "HOTSPOT";
        AI_KOL_ATTENTION: "AI_KOL_ATTENTION";
        DEMAND_VOLUME_OR_GROWTH: "DEMAND_VOLUME_OR_GROWTH";
    }>>;
    outputType: z.ZodLiteral<"OPPORTUNITY_DOSSIER">;
}, z.core.$strict>;
export declare const explicitTopicBriefSchema: z.ZodObject<{
    briefId: z.ZodString;
    briefVersion: z.ZodString;
    primaryObjective: z.ZodEnum<{
        REACH: "REACH";
        VALUE: "VALUE";
        RELATIONSHIP: "RELATIONSHIP";
    }>;
    decisionContext: z.ZodObject<{
        ownerId: z.ZodString;
        targetAccounts: z.ZodArray<z.ZodObject<{
            platform: z.ZodEnum<{
                XIAOHONGSHU: "XIAOHONGSHU";
                JIKE: "JIKE";
                X: "X";
            }>;
            accountId: z.ZodString;
        }, z.core.$strict>>;
        audienceIntents: z.ZodArray<z.ZodEnum<{
            BEGINNER: "BEGINNER";
            BUILDER: "BUILDER";
        }>>;
    }, z.core.$strict>;
    researchWindow: z.ZodObject<{
        since: z.ZodString;
        until: z.ZodString;
        asOf: z.ZodString;
    }, z.core.$strict>;
    locale: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        dimension: z.ZodEnum<{
            DEMAND: "DEMAND";
            SUPPLY_GAP: "SUPPLY_GAP";
            ATTENTION: "ATTENTION";
            TIMING: "TIMING";
            DISTRIBUTION_FIT: "DISTRIBUTION_FIT";
            EXECUTION_READINESS: "EXECUTION_READINESS";
            EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
            LONG_TERM_RELEVANCE: "LONG_TERM_RELEVANCE";
            AUDIENCE_RELEVANCE: "AUDIENCE_RELEVANCE";
            CREDIBILITY_FIT: "CREDIBILITY_FIT";
            COMMUNITY_RELEVANCE: "COMMUNITY_RELEVANCE";
            CONTINUATION_SPACE: "CONTINUATION_SPACE";
        }>;
        question: z.ZodString;
        required: z.ZodBoolean;
        minimumRelevantMaterials: z.ZodNumber;
        minimumIndependentSourceFamilies: z.ZodNumber;
        primarySource: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        counterevidence: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        freshnessDays: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    sourcePolicy: z.ZodObject<{
        required: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        preferred: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        allowed: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        forbidden: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>;
    budget: z.ZodObject<{
        maxProviderCalls: z.ZodNumber;
        maxFetchExtractCalls: z.ZodNumber;
        maxModelInputTokens: z.ZodNumber;
        maxModelOutputTokens: z.ZodNumber;
        maxMaterials: z.ZodNumber;
        maxBytes: z.ZodNumber;
        maxConcurrency: z.ZodNumber;
        deadlineMs: z.ZodNumber;
        maxMoneyMicros: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    stopPolicy: z.ZodObject<{
        whenRequirementsMet: z.ZodLiteral<"STOP_COMPLETE">;
        whenBudgetExhausted: z.ZodLiteral<"STOP_PARTIAL">;
        whenDeadlineExceeded: z.ZodLiteral<"STOP_PARTIAL">;
        whenRequiredSourceUnavailable: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenNoProgress: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenUserCancelled: z.ZodLiteral<"STOP_CANCELLED">;
        maxGapFillAttempts: z.ZodNumber;
    }, z.core.$strict>;
    schemaVersion: z.ZodLiteral<"ExplicitTopicBriefV1">;
    entryMode: z.ZodLiteral<"EXPLICIT_TOPIC">;
    topic: z.ZodObject<{
        title: z.ZodString;
        proposition: z.ZodString;
        userContext: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    analysisPath: z.ZodEnum<{
        ANALYZE_THEN_DECIDE: "ANALYZE_THEN_DECIDE";
        OWNER_DIRECT: "OWNER_DIRECT";
    }>;
    outputType: z.ZodLiteral<"TOPIC_COMPETITIVENESS_REPORT">;
}, z.core.$strict>;
export declare const researchBriefSchema: z.ZodUnion<readonly [z.ZodObject<{
    briefId: z.ZodString;
    briefVersion: z.ZodString;
    primaryObjective: z.ZodEnum<{
        REACH: "REACH";
        VALUE: "VALUE";
        RELATIONSHIP: "RELATIONSHIP";
    }>;
    decisionContext: z.ZodObject<{
        ownerId: z.ZodString;
        targetAccounts: z.ZodArray<z.ZodObject<{
            platform: z.ZodEnum<{
                XIAOHONGSHU: "XIAOHONGSHU";
                JIKE: "JIKE";
                X: "X";
            }>;
            accountId: z.ZodString;
        }, z.core.$strict>>;
        audienceIntents: z.ZodArray<z.ZodEnum<{
            BEGINNER: "BEGINNER";
            BUILDER: "BUILDER";
        }>>;
    }, z.core.$strict>;
    researchWindow: z.ZodObject<{
        since: z.ZodString;
        until: z.ZodString;
        asOf: z.ZodString;
    }, z.core.$strict>;
    locale: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        dimension: z.ZodEnum<{
            DEMAND: "DEMAND";
            SUPPLY_GAP: "SUPPLY_GAP";
            ATTENTION: "ATTENTION";
            TIMING: "TIMING";
            DISTRIBUTION_FIT: "DISTRIBUTION_FIT";
            EXECUTION_READINESS: "EXECUTION_READINESS";
            EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
            LONG_TERM_RELEVANCE: "LONG_TERM_RELEVANCE";
            AUDIENCE_RELEVANCE: "AUDIENCE_RELEVANCE";
            CREDIBILITY_FIT: "CREDIBILITY_FIT";
            COMMUNITY_RELEVANCE: "COMMUNITY_RELEVANCE";
            CONTINUATION_SPACE: "CONTINUATION_SPACE";
        }>;
        question: z.ZodString;
        required: z.ZodBoolean;
        minimumRelevantMaterials: z.ZodNumber;
        minimumIndependentSourceFamilies: z.ZodNumber;
        primarySource: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        counterevidence: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        freshnessDays: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    sourcePolicy: z.ZodObject<{
        required: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        preferred: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        allowed: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        forbidden: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>;
    budget: z.ZodObject<{
        maxProviderCalls: z.ZodNumber;
        maxFetchExtractCalls: z.ZodNumber;
        maxModelInputTokens: z.ZodNumber;
        maxModelOutputTokens: z.ZodNumber;
        maxMaterials: z.ZodNumber;
        maxBytes: z.ZodNumber;
        maxConcurrency: z.ZodNumber;
        deadlineMs: z.ZodNumber;
        maxMoneyMicros: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    stopPolicy: z.ZodObject<{
        whenRequirementsMet: z.ZodLiteral<"STOP_COMPLETE">;
        whenBudgetExhausted: z.ZodLiteral<"STOP_PARTIAL">;
        whenDeadlineExceeded: z.ZodLiteral<"STOP_PARTIAL">;
        whenRequiredSourceUnavailable: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenNoProgress: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenUserCancelled: z.ZodLiteral<"STOP_CANCELLED">;
        maxGapFillAttempts: z.ZodNumber;
    }, z.core.$strict>;
    schemaVersion: z.ZodLiteral<"OpenDiscoveryBriefV1">;
    entryMode: z.ZodLiteral<"OPEN_DISCOVERY">;
    domainPrompt: z.ZodString;
    signalLenses: z.ZodArray<z.ZodEnum<{
        SUPPLY_GAP: "SUPPLY_GAP";
        HOTSPOT: "HOTSPOT";
        AI_KOL_ATTENTION: "AI_KOL_ATTENTION";
        DEMAND_VOLUME_OR_GROWTH: "DEMAND_VOLUME_OR_GROWTH";
    }>>;
    outputType: z.ZodLiteral<"OPPORTUNITY_DOSSIER">;
}, z.core.$strict>, z.ZodObject<{
    briefId: z.ZodString;
    briefVersion: z.ZodString;
    primaryObjective: z.ZodEnum<{
        REACH: "REACH";
        VALUE: "VALUE";
        RELATIONSHIP: "RELATIONSHIP";
    }>;
    decisionContext: z.ZodObject<{
        ownerId: z.ZodString;
        targetAccounts: z.ZodArray<z.ZodObject<{
            platform: z.ZodEnum<{
                XIAOHONGSHU: "XIAOHONGSHU";
                JIKE: "JIKE";
                X: "X";
            }>;
            accountId: z.ZodString;
        }, z.core.$strict>>;
        audienceIntents: z.ZodArray<z.ZodEnum<{
            BEGINNER: "BEGINNER";
            BUILDER: "BUILDER";
        }>>;
    }, z.core.$strict>;
    researchWindow: z.ZodObject<{
        since: z.ZodString;
        until: z.ZodString;
        asOf: z.ZodString;
    }, z.core.$strict>;
    locale: z.ZodString;
    questions: z.ZodArray<z.ZodObject<{
        questionId: z.ZodString;
        dimension: z.ZodEnum<{
            DEMAND: "DEMAND";
            SUPPLY_GAP: "SUPPLY_GAP";
            ATTENTION: "ATTENTION";
            TIMING: "TIMING";
            DISTRIBUTION_FIT: "DISTRIBUTION_FIT";
            EXECUTION_READINESS: "EXECUTION_READINESS";
            EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
            LONG_TERM_RELEVANCE: "LONG_TERM_RELEVANCE";
            AUDIENCE_RELEVANCE: "AUDIENCE_RELEVANCE";
            CREDIBILITY_FIT: "CREDIBILITY_FIT";
            COMMUNITY_RELEVANCE: "COMMUNITY_RELEVANCE";
            CONTINUATION_SPACE: "CONTINUATION_SPACE";
        }>;
        question: z.ZodString;
        required: z.ZodBoolean;
        minimumRelevantMaterials: z.ZodNumber;
        minimumIndependentSourceFamilies: z.ZodNumber;
        primarySource: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        counterevidence: z.ZodEnum<{
            REQUIRED: "REQUIRED";
            PREFERRED: "PREFERRED";
            NOT_REQUIRED: "NOT_REQUIRED";
        }>;
        freshnessDays: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    sourcePolicy: z.ZodObject<{
        required: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        preferred: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        allowed: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
        forbidden: z.ZodArray<z.ZodDiscriminatedUnion<[z.ZodObject<{
            kind: z.ZodLiteral<"SEL_CHANNEL">;
            value: z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
            }>;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"PROVIDER">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"DOMAIN">;
            value: z.ZodString;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"URL">;
            value: z.ZodURL;
        }, z.core.$strict>, z.ZodObject<{
            kind: z.ZodLiteral<"CGS_INPUT">;
            value: z.ZodEnum<{
                AI_KOL_SNAPSHOT: "AI_KOL_SNAPSHOT";
                AUTHORIZED_PLATFORM_MATERIAL: "AUTHORIZED_PLATFORM_MATERIAL";
            }>;
        }, z.core.$strict>], "kind">>;
    }, z.core.$strict>;
    budget: z.ZodObject<{
        maxProviderCalls: z.ZodNumber;
        maxFetchExtractCalls: z.ZodNumber;
        maxModelInputTokens: z.ZodNumber;
        maxModelOutputTokens: z.ZodNumber;
        maxMaterials: z.ZodNumber;
        maxBytes: z.ZodNumber;
        maxConcurrency: z.ZodNumber;
        deadlineMs: z.ZodNumber;
        maxMoneyMicros: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>;
    stopPolicy: z.ZodObject<{
        whenRequirementsMet: z.ZodLiteral<"STOP_COMPLETE">;
        whenBudgetExhausted: z.ZodLiteral<"STOP_PARTIAL">;
        whenDeadlineExceeded: z.ZodLiteral<"STOP_PARTIAL">;
        whenRequiredSourceUnavailable: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenNoProgress: z.ZodLiteral<"STOP_INSUFFICIENT">;
        whenUserCancelled: z.ZodLiteral<"STOP_CANCELLED">;
        maxGapFillAttempts: z.ZodNumber;
    }, z.core.$strict>;
    schemaVersion: z.ZodLiteral<"ExplicitTopicBriefV1">;
    entryMode: z.ZodLiteral<"EXPLICIT_TOPIC">;
    topic: z.ZodObject<{
        title: z.ZodString;
        proposition: z.ZodString;
        userContext: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>;
    analysisPath: z.ZodEnum<{
        ANALYZE_THEN_DECIDE: "ANALYZE_THEN_DECIDE";
        OWNER_DIRECT: "OWNER_DIRECT";
    }>;
    outputType: z.ZodLiteral<"TOPIC_COMPETITIVENESS_REPORT">;
}, z.core.$strict>]>;
export type ResearchBrief = z.infer<typeof researchBriefSchema>;
export declare function parseResearchBrief(input: unknown): ResearchBrief;
export declare function assertBriefConformsToContract(briefInput: unknown, contractInput: unknown): ResearchBrief;
type CgsInputValue = Extract<SourceSelector, {
    kind: "CGS_INPUT";
}>["value"];
export interface ResearchIntentSpec {
    readonly schemaVersion: "CGSResearchIntentSpecV1";
    readonly questionId: string;
    readonly evidenceRole: "PRIMARY" | "COUNTEREVIDENCE";
    readonly taskProfile: SearchIntentTaskProfileV1;
    readonly query: string;
    readonly sourcePolicy: SearchIntentSourcePolicyV1;
    readonly cgsInputPolicy: Readonly<{
        required: readonly CgsInputValue[];
        preferred: readonly CgsInputValue[];
        allowed: readonly CgsInputValue[];
        forbidden: readonly CgsInputValue[];
    }>;
    readonly constraints: Readonly<{
        locale: string;
        timeRange: Readonly<{
            since: string;
            until: string;
        }>;
    }>;
    readonly budget: SearchIntentExecutionBudgetV1;
    readonly partialPolicy: "allow_partial";
    readonly evidenceRequirement: "PRIMARY_USER_EXPRESSION_REQUIRED_FOR_STRONG_CLAIM" | "SOURCE_POLICY_APPLIES";
    readonly providerPolicy: Readonly<{
        dependency: "OPTIONAL_AND_REPLACEABLE";
        failureBehavior: "CONTINUE_WITH_PROVIDER_GAP";
    }>;
}
export declare function compileResearchIntentSpecs(briefInput: unknown, contractInput: unknown): ResearchIntentSpec[];
export declare const aiKolSourceSnapshotSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<"AIKOLSourceSnapshotV1">;
    snapshotId: z.ZodString;
    snapshotVersion: z.ZodString;
    capturedAt: z.ZodString;
    input: z.ZodDiscriminatedUnion<[z.ZodObject<{
        kind: z.ZodLiteral<"USER_LIST">;
        sourceRef: z.ZodString;
    }, z.core.$strict>, z.ZodObject<{
        kind: z.ZodLiteral<"USER_SKILL">;
        skillRef: z.ZodString;
        invocationRef: z.ZodString;
    }, z.core.$strict>], "kind">;
    entries: z.ZodArray<z.ZodObject<{
        kolId: z.ZodString;
        displayName: z.ZodString;
        identityStatus: z.ZodEnum<{
            CANDIDATE: "CANDIDATE";
            USER_CONFIRMED: "USER_CONFIRMED";
        }>;
        identityEvidenceRefs: z.ZodArray<z.ZodString>;
        accounts: z.ZodArray<z.ZodObject<{
            platform: z.ZodEnum<{
                XIAOHONGSHU: "XIAOHONGSHU";
                JIKE: "JIKE";
                ZHIHU: "ZHIHU";
                X: "X";
                REDDIT: "REDDIT";
                DOUYIN: "DOUYIN";
                WECHAT_OFFICIAL: "WECHAT_OFFICIAL";
                BILIBILI: "BILIBILI";
            }>;
            accountRef: z.ZodString;
            profileUrl: z.ZodOptional<z.ZodURL>;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type AIKOLSourceSnapshot = z.infer<typeof aiKolSourceSnapshotSchema>;
export declare function parseAIKOLSourceSnapshot(input: unknown): AIKOLSourceSnapshot;
export declare const researchBenchmarkSuiteSchema: z.ZodObject<{
    schemaVersion: z.ZodLiteral<"ResearchBenchmarkSuiteV1">;
    suiteVersion: z.ZodString;
    realAiKolFixtureStatus: z.ZodEnum<{
        USER_CONFIRMED: "USER_CONFIRMED";
        PENDING_USER_INPUT: "PENDING_USER_INPUT";
    }>;
    aiKolSnapshotRef: z.ZodOptional<z.ZodString>;
    cases: z.ZodArray<z.ZodObject<{
        caseId: z.ZodString;
        title: z.ZodString;
        tags: z.ZodArray<z.ZodEnum<{
            EXPLICIT_TOPIC: "EXPLICIT_TOPIC";
            SATURATED_REACH: "SATURATED_REACH";
            GAP_VALUE: "GAP_VALUE";
            AI_KOL_RELATIONSHIP: "AI_KOL_RELATIONSHIP";
            DUPLICATE_AI_KOL: "DUPLICATE_AI_KOL";
            INSUFFICIENT_EVIDENCE: "INSUFFICIENT_EVIDENCE";
            OPTIONAL_PROVIDER_OUTAGE: "OPTIONAL_PROVIDER_OUTAGE";
        }>>;
        entryMode: z.ZodEnum<{
            OPEN_DISCOVERY: "OPEN_DISCOVERY";
            EXPLICIT_TOPIC: "EXPLICIT_TOPIC";
        }>;
        primaryObjective: z.ZodEnum<{
            REACH: "REACH";
            VALUE: "VALUE";
            RELATIONSHIP: "RELATIONSHIP";
        }>;
        briefRef: z.ZodString;
        observations: z.ZodObject<{
            demand: z.ZodEnum<{
                ABSENT: "ABSENT";
                PRESENT: "PRESENT";
                GROWING: "GROWING";
                UNKNOWN: "UNKNOWN";
            }>;
            supply: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                LOW: "LOW";
                MODERATE: "MODERATE";
                SATURATED: "SATURATED";
            }>;
            supplyGap: z.ZodEnum<{
                ABSENT: "ABSENT";
                PRESENT: "PRESENT";
                UNKNOWN: "UNKNOWN";
            }>;
            attention: z.ZodEnum<{
                ACTIVE: "ACTIVE";
                UNKNOWN: "UNKNOWN";
                LOW: "LOW";
                SURGING: "SURGING";
            }>;
            timing: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                CLOSED: "CLOSED";
                OPEN: "OPEN";
            }>;
            distributionFit: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                WEAK: "WEAK";
                PLAUSIBLE: "PLAUSIBLE";
                STRONG: "STRONG";
            }>;
            executionReadiness: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                WEAK: "WEAK";
                PLAUSIBLE: "PLAUSIBLE";
                STRONG: "STRONG";
            }>;
            evidenceAdvantage: z.ZodEnum<{
                ABSENT: "ABSENT";
                UNKNOWN: "UNKNOWN";
                PLAUSIBLE: "PLAUSIBLE";
                STRONG: "STRONG";
            }>;
            relationshipRelevance: z.ZodEnum<{
                UNKNOWN: "UNKNOWN";
                LOW: "LOW";
                PLAUSIBLE: "PLAUSIBLE";
                STRONG: "STRONG";
            }>;
            sourceFamilyCount: z.ZodNumber;
            counterevidence: z.ZodEnum<{
                ABSENT: "ABSENT";
                PRESENT: "PRESENT";
                UNKNOWN: "UNKNOWN";
            }>;
            aiKolSignals: z.ZodArray<z.ZodObject<{
                signalId: z.ZodString;
                kolId: z.ZodString;
                materialRef: z.ZodString;
                originalStatementRef: z.ZodString;
                sourceFamilyRef: z.ZodString;
            }, z.core.$strict>>;
            providerFailures: z.ZodOptional<z.ZodArray<z.ZodObject<{
                providerId: z.ZodString;
                errorCode: z.ZodString;
                required: z.ZodBoolean;
            }, z.core.$strict>>>;
            successfulChannels: z.ZodOptional<z.ZodArray<z.ZodEnum<{
                repository: "repository";
                web: "web";
                rss: "rss";
                official: "official";
                community: "community";
                authorized_input: "authorized_input";
                ai_kol_input: "ai_kol_input";
            }>>>;
        }, z.core.$strict>;
        expected: z.ZodObject<{
            outcome: z.ZodEnum<{
                QUALIFIES_FOR_REVIEW: "QUALIFIES_FOR_REVIEW";
                QUALIFIES_WITH_ADJUSTMENT: "QUALIFIES_WITH_ADJUSTMENT";
                WATCH: "WATCH";
                INSUFFICIENT: "INSUFFICIENT";
                DOES_NOT_QUALIFY: "DOES_NOT_QUALIFY";
            }>;
            reasons: z.ZodArray<z.ZodString>;
            mustExpose: z.ZodArray<z.ZodEnum<{
                EVIDENCE_ADVANTAGE: "EVIDENCE_ADVANTAGE";
                COUNTEREVIDENCE: "COUNTEREVIDENCE";
                COMPETITION_PRESSURE: "COMPETITION_PRESSURE";
                TIMING_WINDOW: "TIMING_WINDOW";
                SOURCE_INDEPENDENCE: "SOURCE_INDEPENDENCE";
                COVERAGE_GAP: "COVERAGE_GAP";
                AI_KOL_AMPLIFICATION: "AI_KOL_AMPLIFICATION";
                FAILURE_CONDITIONS: "FAILURE_CONDITIONS";
            }>>;
        }, z.core.$strict>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ResearchBenchmarkSuite = z.infer<typeof researchBenchmarkSuiteSchema>;
export declare function parseResearchBenchmarkSuite(input: unknown): ResearchBenchmarkSuite;
export declare function benchmarkCoverage(input: unknown): {
    requiredCasesCovered: boolean;
    coveredTags: string[];
    readyForRealAIKOLAcceptance: boolean;
};
export {};
