import type { ArtifactKey, ArtifactState, ManuscriptSnapshot } from "./creation-artifacts.ts";
import { type TopicSelection } from "./topics.ts";
import { z } from "zod";
import type { CreationRuntimeState, MethodRuntime } from "./creation-runtime.ts";
import type { ModelExecution } from "./creation-model-receipt.ts";
import type { OutputConstraints } from "./creation-output-constraints.ts";
import { type CreationResearchRun } from "./creation-research.ts";
export type { CreationRuntimeState, MethodRuntime, RuntimeKind, RuntimeSession, RuntimeSelection } from "./creation-runtime.ts";
export declare const planSchema: z.ZodObject<{
    title: z.ZodString;
    core: z.ZodString;
    outline: z.ZodString;
    evidence: z.ZodString;
    boundaries: z.ZodString;
}, z.core.$strict>;
export declare const planComparisonSchema: z.ZodObject<{
    direction: z.ZodEnum<{
        SAME_DIRECTION: "SAME_DIRECTION";
        NEW_ANGLE: "NEW_ANGLE";
        OPPOSITE: "OPPOSITE";
        UNCERTAIN: "UNCERTAIN";
    }>;
    summary: z.ZodString;
    currentView: z.ZodString;
    proposedView: z.ZodString;
    reason: z.ZodString;
    tradeoff: z.ZodString;
    anchors: z.ZodObject<{
        before: z.ZodString;
        after: z.ZodString;
    }, z.core.$strict>;
}, z.core.$strict>;
export type PlanComparison = z.infer<typeof planComparisonSchema>;
export declare const accountSchema: z.ZodObject<{
    id: z.ZodString;
    name: z.ZodString;
    audience: z.ZodString;
    voice: z.ZodString;
    boundaries: z.ZodString;
    profile: z.ZodOptional<z.ZodObject<{
        experience: z.ZodString;
        opinions: z.ZodString;
        value: z.ZodString;
        curiosity: z.ZodString;
        ai: z.ZodString;
        style: z.ZodString;
        publishing: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const nextStepsSchema: z.ZodArray<z.ZodObject<{
    label: z.ZodString;
    reason: z.ZodString;
    prompt: z.ZodString;
}, z.core.$strict>>;
export type NextStep = z.infer<typeof nextStepsSchema>[number];
export declare const materialInsightSchema: z.ZodObject<{
    summary: z.ZodString;
    relation: z.ZodString;
    next: z.ZodString;
    quote: z.ZodString;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    nextStepsBasis: z.ZodOptional<z.ZodString>;
    nextStepsAt: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const materialUseSchema: z.ZodEnum<{
    SUPPORT: "SUPPORT";
    EXPLORE: "EXPLORE";
    COMPARE: "COMPARE";
    EXPRESSION: "EXPRESSION";
}>;
export declare const sourceSchema: z.ZodObject<{
    text: z.ZodString;
    files: z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        text: z.ZodString;
        provenance: z.ZodOptional<z.ZodObject<{
            sourceId: z.ZodString;
            role: z.ZodEnum<{
                ORIGINAL: "ORIGINAL";
                REPORT: "REPORT";
            }>;
            readScope: z.ZodEnum<{
                FULL: "FULL";
                PARTIAL: "PARTIAL";
                REFERENCE_ONLY: "REFERENCE_ONLY";
            }>;
            originalUrl: z.ZodOptional<z.ZodURL>;
            observedAt: z.ZodOptional<z.ZodString>;
            publishedAt: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        extraction: z.ZodOptional<z.ZodObject<{
            extractor: z.ZodString;
            coverage: z.ZodObject<{
                status: z.ZodEnum<{
                    sufficient: "sufficient";
                    partial: "partial";
                    insufficient: "insufficient";
                }>;
                truncated: z.ZodOptional<z.ZodBoolean>;
                processed_pages: z.ZodNumber;
                total_pages: z.ZodNumber;
                issues: z.ZodArray<z.ZodString>;
            }, z.core.$strict>;
            locations: z.ZodArray<z.ZodObject<{
                page: z.ZodOptional<z.ZodNumber>;
                start_seconds: z.ZodOptional<z.ZodNumber>;
                end_seconds: z.ZodOptional<z.ZodNumber>;
                text: z.ZodString;
            }, z.core.$strict>>;
            duration_seconds: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        attachment: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            format: z.ZodEnum<{
                PDF: "PDF";
                DOCX: "DOCX";
                TEXT: "TEXT";
                IMAGE: "IMAGE";
                AUDIO: "AUDIO";
                VIDEO: "VIDEO";
            }>;
            sha256: z.ZodOptional<z.ZodString>;
            size: z.ZodNumber;
            pages: z.ZodOptional<z.ZodNumber>;
            needsOcr: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>>;
        intents: z.ZodOptional<z.ZodArray<z.ZodEnum<{
            SUPPORT: "SUPPORT";
            EXPLORE: "EXPLORE";
            COMPARE: "COMPARE";
            EXPRESSION: "EXPRESSION";
        }>>>;
        focus: z.ZodOptional<z.ZodString>;
        excluded: z.ZodOptional<z.ZodBoolean>;
        processing: z.ZodOptional<z.ZodObject<{
            id: z.ZodString;
            status: z.ZodEnum<{
                FAILED: "FAILED";
                READING: "READING";
                UNDERSTANDING: "UNDERSTANDING";
                READY: "READY";
                NEEDS_LOGIN: "NEEDS_LOGIN";
            }>;
            message: z.ZodString;
            context: z.ZodString;
        }, z.core.$strict>>;
        insight: z.ZodOptional<z.ZodObject<{
            summary: z.ZodString;
            relation: z.ZodString;
            next: z.ZodString;
            quote: z.ZodString;
            nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
                label: z.ZodString;
                reason: z.ZodString;
                prompt: z.ZodString;
            }, z.core.$strict>>>;
            nextStepsBasis: z.ZodOptional<z.ZodString>;
            nextStepsAt: z.ZodOptional<z.ZodString>;
        }, z.core.$strict>>;
        originalText: z.ZodOptional<z.ZodString>;
        url: z.ZodOptional<z.ZodURL>;
        resolvedUrl: z.ZodOptional<z.ZodURL>;
        retrievedAt: z.ZodOptional<z.ZodString>;
        kind: z.ZodOptional<z.ZodEnum<{
            WEB_TEXT: "WEB_TEXT";
            VIDEO_TRANSCRIPT: "VIDEO_TRANSCRIPT";
            AUDIO_TRANSCRIPT: "AUDIO_TRANSCRIPT";
            USER_TRANSCRIPT: "USER_TRANSCRIPT";
            DOCUMENT_TEXT: "DOCUMENT_TEXT";
            IMAGE_TEXT: "IMAGE_TEXT";
            FEED_DIRECTORY: "FEED_DIRECTORY";
        }>>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const targetSchema: z.ZodObject<{
    platform: z.ZodString;
    carrier: z.ZodString;
    account: z.ZodString;
}, z.core.$strict>;
export declare const outputSchema: z.ZodObject<{
    title: z.ZodString;
    body: z.ZodString;
    cards: z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strict>>;
}, z.core.$strict>;
export declare const preferenceChangeSchema: z.ZodObject<{
    quote: z.ZodString;
    voice: z.ZodOptional<z.ZodString>;
    boundaries: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const editScopeSchema: z.ZodObject<{
    type: z.ZodEnum<{
        ALL: "ALL";
        TITLE: "TITLE";
        BODY: "BODY";
        CARD: "CARD";
    }>;
    cardIndex: z.ZodOptional<z.ZodNumber>;
}, z.core.$strict>;
export declare const applyIntentSchema: z.ZodEnum<{
    NONE: "NONE";
    AUTO: "AUTO";
    CREATE_DRAFT: "CREATE_DRAFT";
    REVISE: "REVISE";
    PROPOSE: "PROPOSE";
}>;
export type ApplyIntent = z.infer<typeof applyIntentSchema>;
export declare const applyStatusSchema: z.ZodEnum<{
    NONE: "NONE";
    APPLIED: "APPLIED";
    SUGGESTED: "SUGGESTED";
    DEFERRED: "DEFERRED";
}>;
export type ApplyStatus = z.infer<typeof applyStatusSchema>;
export declare const draftOriginSchema: z.ZodEnum<{
    GENERATED: "GENERATED";
    AUTHOR_ADOPTED: "AUTHOR_ADOPTED";
    AUTHOR_RESTORED: "AUTHOR_RESTORED";
    AUTHOR_MANUAL: "AUTHOR_MANUAL";
}>;
export type DraftOrigin = z.infer<typeof draftOriginSchema>;
export declare const artifactRoleSchema: z.ZodEnum<{
    revision: "revision";
    proposal: "proposal";
}>;
export type ArtifactRole = z.infer<typeof artifactRoleSchema>;
export declare const reviewIssueRefSchema: z.ZodObject<{
    location: z.ZodString;
    quote: z.ZodOptional<z.ZodString>;
    problem: z.ZodString;
    evidence: z.ZodString;
    suggestion: z.ZodString;
    needsAuthor: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export declare const contentCitationSchema: z.ZodObject<{
    kind: z.ZodEnum<{
        TITLE: "TITLE";
        BODY: "BODY";
        PAGE: "PAGE";
        PLAN: "PLAN";
        OUTPUT: "OUTPUT";
    }>;
    page: z.ZodOptional<z.ZodNumber>;
    field: z.ZodOptional<z.ZodEnum<{
        title: "title";
        evidence: "evidence";
        boundaries: "boundaries";
        core: "core";
        outline: "outline";
    }>>;
    label: z.ZodString;
    issue: z.ZodOptional<z.ZodObject<{
        location: z.ZodString;
        quote: z.ZodOptional<z.ZodString>;
        problem: z.ZodString;
        evidence: z.ZodString;
        suggestion: z.ZodString;
        needsAuthor: z.ZodOptional<z.ZodBoolean>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type ContentCitation = z.infer<typeof contentCitationSchema>;
export declare const discussionResultSchema: z.ZodObject<{
    message: z.ZodString;
    researchNeed: z.ZodOptional<z.ZodObject<{
        question: z.ZodString;
        impact: z.ZodString;
        evidenceNeeded: z.ZodArray<z.ZodString>;
        stopWhen: z.ZodString;
        query: z.ZodString;
    }, z.core.$strict>>;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    preferenceChange: z.ZodOptional<z.ZodObject<{
        quote: z.ZodString;
        voice: z.ZodOptional<z.ZodString>;
        boundaries: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    preferenceBefore: z.ZodOptional<z.ZodObject<{
        id: z.ZodString;
        name: z.ZodString;
        audience: z.ZodString;
        voice: z.ZodString;
        boundaries: z.ZodString;
        profile: z.ZodOptional<z.ZodObject<{
            experience: z.ZodString;
            opinions: z.ZodString;
            value: z.ZodString;
            curiosity: z.ZodString;
            ai: z.ZodString;
            style: z.ZodString;
            publishing: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>>;
    preferenceUndone: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type DiscussionResult = z.infer<typeof discussionResultSchema>;
export declare const planResultSchema: z.ZodObject<{
    message: z.ZodString;
    question: z.ZodNullable<z.ZodString>;
    plan: z.ZodObject<{
        title: z.ZodString;
        core: z.ZodString;
        outline: z.ZodString;
        evidence: z.ZodString;
        boundaries: z.ZodString;
    }, z.core.$strict>;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    role: z.ZodOptional<z.ZodEnum<{
        revision: "revision";
        proposal: "proposal";
    }>>;
}, z.core.$strict>;
export declare const planSaveSchema: z.ZodObject<{
    message: z.ZodString;
    question: z.ZodNullable<z.ZodString>;
    plan: z.ZodObject<{
        title: z.ZodString;
        core: z.ZodString;
        outline: z.ZodString;
        evidence: z.ZodString;
        boundaries: z.ZodString;
    }, z.core.$strict>;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    role: z.ZodEnum<{
        revision: "revision";
        proposal: "proposal";
    }>;
}, z.core.$strict>;
export declare const planUpdateSchema: z.ZodObject<{
    message: z.ZodString;
    role: z.ZodEnum<{
        revision: "revision";
        proposal: "proposal";
    }>;
    title: z.ZodOptional<z.ZodString>;
    core: z.ZodOptional<z.ZodString>;
    outline: z.ZodOptional<z.ZodString>;
    evidence: z.ZodOptional<z.ZodString>;
    boundaries: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export type PlanUpdate = z.infer<typeof planUpdateSchema>;
export declare const editorialCheckSchema: z.ZodObject<{
    status: z.ZodEnum<{
        CHECKED: "CHECKED";
        NEEDS_AUTHOR: "NEEDS_AUTHOR";
        INCOMPLETE: "INCOMPLETE";
    }>;
    issues: z.ZodArray<z.ZodObject<{
        quote: z.ZodOptional<z.ZodString>;
        location: z.ZodString;
        problem: z.ZodString;
        evidence: z.ZodString;
        suggestion: z.ZodString;
        needsAuthor: z.ZodBoolean;
    }, z.core.$strict>>;
    repaired: z.ZodBoolean;
    reason: z.ZodOptional<z.ZodEnum<{
        CONNECTION: "CONNECTION";
        FORMAT: "FORMAT";
        UNGROUNDED: "UNGROUNDED";
        REPAIR_FAILED: "REPAIR_FAILED";
    }>>;
    diagnostic: z.ZodOptional<z.ZodString>;
}, z.core.$strict>;
export declare const generationResultSchema: z.ZodObject<{
    message: z.ZodString;
    output: z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
        cards: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    conception: z.ZodOptional<z.ZodObject<{
        title: z.ZodString;
        core: z.ZodString;
        outline: z.ZodString;
        evidence: z.ZodString;
        boundaries: z.ZodString;
    }, z.core.$strict>>;
    review: z.ZodArray<z.ZodString>;
    sourceMap: z.ZodArray<z.ZodString>;
    check: z.ZodOptional<z.ZodObject<{
        status: z.ZodEnum<{
            CHECKED: "CHECKED";
            NEEDS_AUTHOR: "NEEDS_AUTHOR";
            INCOMPLETE: "INCOMPLETE";
        }>;
        issues: z.ZodArray<z.ZodObject<{
            quote: z.ZodOptional<z.ZodString>;
            location: z.ZodString;
            problem: z.ZodString;
            evidence: z.ZodString;
            suggestion: z.ZodString;
            needsAuthor: z.ZodBoolean;
        }, z.core.$strict>>;
        repaired: z.ZodBoolean;
        reason: z.ZodOptional<z.ZodEnum<{
            CONNECTION: "CONNECTION";
            FORMAT: "FORMAT";
            UNGROUNDED: "UNGROUNDED";
            REPAIR_FAILED: "REPAIR_FAILED";
        }>>;
        diagnostic: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>;
    authorQuestions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        quote: z.ZodOptional<z.ZodString>;
        problem: z.ZodString;
        evidence: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        suggestion: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        location: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        needsAuthor: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    }, z.core.$strict>>>;
    editScope: z.ZodOptional<z.ZodObject<{
        type: z.ZodEnum<{
            ALL: "ALL";
            TITLE: "TITLE";
            BODY: "BODY";
            CARD: "CARD";
        }>;
        cardIndex: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    role: z.ZodOptional<z.ZodEnum<{
        revision: "revision";
        proposal: "proposal";
    }>>;
    importKind: z.ZodOptional<z.ZodEnum<{
        MANUSCRIPT: "MANUSCRIPT";
    }>>;
}, z.core.$strict>;
export declare const generationSaveSchema: z.ZodObject<{
    message: z.ZodString;
    output: z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
        cards: z.ZodArray<z.ZodObject<{
            title: z.ZodString;
            body: z.ZodString;
        }, z.core.$strict>>;
    }, z.core.$strict>;
    nextSteps: z.ZodOptional<z.ZodArray<z.ZodObject<{
        label: z.ZodString;
        reason: z.ZodString;
        prompt: z.ZodString;
    }, z.core.$strict>>>;
    conception: z.ZodOptional<z.ZodObject<{
        title: z.ZodString;
        core: z.ZodString;
        outline: z.ZodString;
        evidence: z.ZodString;
        boundaries: z.ZodString;
    }, z.core.$strict>>;
    review: z.ZodArray<z.ZodString>;
    sourceMap: z.ZodArray<z.ZodString>;
    authorQuestions: z.ZodOptional<z.ZodArray<z.ZodObject<{
        quote: z.ZodOptional<z.ZodString>;
        problem: z.ZodString;
        evidence: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        suggestion: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        location: z.ZodDefault<z.ZodOptional<z.ZodString>>;
        needsAuthor: z.ZodDefault<z.ZodOptional<z.ZodBoolean>>;
    }, z.core.$strict>>>;
    editScope: z.ZodOptional<z.ZodObject<{
        type: z.ZodEnum<{
            ALL: "ALL";
            TITLE: "TITLE";
            BODY: "BODY";
            CARD: "CARD";
        }>;
        cardIndex: z.ZodOptional<z.ZodNumber>;
    }, z.core.$strict>>;
    role: z.ZodEnum<{
        revision: "revision";
        proposal: "proposal";
    }>;
}, z.core.$strict>;
export declare const manuscriptImportSchema: z.ZodObject<{
    message: z.ZodString;
    role: z.ZodEnum<{
        revision: "revision";
        proposal: "proposal";
    }>;
    title: z.ZodOptional<z.ZodString>;
    body: z.ZodString;
    cards: z.ZodOptional<z.ZodArray<z.ZodObject<{
        title: z.ZodString;
        body: z.ZodString;
    }, z.core.$strict>>>;
    replace: z.ZodOptional<z.ZodBoolean>;
}, z.core.$strict>;
export type ManuscriptImport = z.infer<typeof manuscriptImportSchema>;
export type Plan = z.infer<typeof planSchema>;
export type Account = z.infer<typeof accountSchema>;
export type Output = z.infer<typeof outputSchema>;
export type Source = z.infer<typeof sourceSchema>;
export type Material = Source["files"][number];
export type MaterialInsight = z.infer<typeof materialInsightSchema>;
export type MaterialContext = {
    creation?: {
        plan: Plan;
        account: Account | null;
        target: Target;
        output?: Output | null;
    };
    idea: string;
    material: Material;
    companions: {
        name: string;
        text: string;
    }[];
};
export declare const materialContext: (doc: Pick<Creation, "source" | "plan">) => string;
export type Target = z.infer<typeof targetSchema>;
export type PlanResult = z.infer<typeof planResultSchema>;
export type GenerationResult = z.infer<typeof generationResultSchema>;
export type Method = {
    version: string;
    hash: string;
    files: {
        path: string;
        text: string;
    }[];
    model: string;
    provider?: string;
    runtime?: MethodRuntime;
};
export type Base = {
    manuscript?: ManuscriptSnapshot;
    artifact?: ArtifactKey;
    id: string;
    hash: string;
    at: string;
    source: Source;
    account: Account | null;
    plan: Plan;
    target: Target;
};
export type Version = {
    artifact?: ArtifactKey;
    id: string;
    at: string;
    baseId: string;
    hash: string;
    output: Output;
    assets: string[];
    renderer: string;
    origin: "AI" | "MANUAL";
    parentId: string | null;
    operationId: string | null;
    review: string[];
    sourceMap: string[];
    check?: z.infer<typeof editorialCheckSchema>;
};
export declare const feedbackTargetSchema: z.ZodDiscriminatedUnion<[z.ZodObject<{
    type: z.ZodLiteral<"WORKING">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"BASE">;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"PLAN_CANDIDATE">;
    operationId: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"VERSION">;
    versionId: z.ZodString;
}, z.core.$strict>, z.ZodObject<{
    type: z.ZodLiteral<"RETRY">;
    operationId: z.ZodString;
}, z.core.$strict>], "type">;
export type FeedbackTarget = z.infer<typeof feedbackTargetSchema>;
export declare const inputReferenceSchema: z.ZodObject<{
    versionId: z.ZodNullable<z.ZodString>;
    derivedFromVersionId: z.ZodNullable<z.ZodString>;
    contentHash: z.ZodString;
}, z.core.$strict>;
export type InputReference = z.infer<typeof inputReferenceSchema>;
export type AppliedUpdate = {
    artifact?: ArtifactKey;
    beforeSource?: ManuscriptSnapshot;
    id: string;
    at: string;
    kind: "PLAN" | "GENERATE";
    beforePlan: Plan;
    beforeWorking: Output | null;
    beforeWorkingBaseId: string | null;
    beforeWorkingVersionId: string | null;
    beforePlanOrigin?: DraftOrigin | null;
    beforeWorkingOrigin?: DraftOrigin | null;
    afterPlanHash: string | null;
    afterWorkingHash: string | null;
    undone?: boolean;
};
export type Operation = {
    outputConstraints?: OutputConstraints;
    artifact?: ArtifactKey;
    mode?: "DISCUSS" | "CREATE" | "AUTO" | "REVIEW";
    requestedMode?: "DISCUSS" | "CREATE" | "AUTO" | "REVIEW";
    progress?: string;
    target?: FeedbackTarget;
    id: string;
    fingerprint: string;
    kind: "PLAN" | "GENERATE";
    status: "RUNNING" | "SUCCEEDED" | "FAILED";
    startedAt: string;
    finishedAt: string | null;
    feedback: string;
    feedbackOrigin?: "AUTHOR" | "ASSISTANT";
    authorFeedback?: {
        text: string;
        confirmedAt: string;
    };
    applyIntent?: ApplyIntent;
    citation?: ContentCitation;
    applyStatus?: ApplyStatus;
    deferredMessage?: string;
    lockedPlanHash?: string;
    lockedWorkingHash?: string;
    batchId?: string;
    input: {
        manuscript?: ManuscriptSnapshot;
        references?: {
            id: string;
            kind: string;
            title: string;
            at: string;
            hash: string;
        }[];
        reference?: InputReference;
        source: Source;
        account: Account | null;
        plan: Plan;
        target: Target;
        base: Base | null;
        output: Output | null;
        history: {
            feedback: string;
            response: string;
            operationId?: string;
            at?: string;
            context?: string;
        }[];
        memory?: {
            omitted: number;
            decisions: string[];
            preferences: Account | null;
        };
    };
    method: Method;
    execution?: ModelExecution;
    result: PlanResult | GenerationResult | DiscussionResult | null;
    error: string | null;
    diagnostic?: {
        providerOutput: string;
        details: string;
    };
    recovery?: "CANDIDATE_RECEIVED";
    versionId: string | null;
};
export type Creation = {
    initialRequestHash?: string;
    researchRuns?: CreationResearchRun[];
    topic?: TopicSelection;
    artifacts?: Record<ArtifactKey, ArtifactState>;
    schemaVersion: 1;
    id: string;
    revision: number;
    createdAt: string;
    updatedAt: string;
    source: Source;
    account: Account | null;
    plan: Plan;
    target: Target;
    working: Output | null;
    workingBaseId: string | null;
    workingVersionId: string | null;
    planOrigin?: DraftOrigin | null;
    workingOrigin?: DraftOrigin | null;
    appliedUpdates?: AppliedUpdate[];
    bases: Base[];
    versions: Version[];
    approvals: {
        id: string;
        at: string;
        versionId: string;
        baseHash: string;
        outputHash: string;
        assetHashes: string[];
    }[];
    operations: Operation[];
    adoptedPlanOperationId?: string | null;
    planHistory?: {
        id: string;
        at: string;
        plan: Plan;
    }[];
    runtime?: CreationRuntimeState;
};
export declare const emptyPlan: () => Plan;
export declare function planHasContent(plan: Plan | null | undefined): boolean;
export declare function digest(value: unknown): string;
export declare function baseHash(doc: Pick<Creation, "source" | "account" | "plan" | "target">): string;
export declare function currentBase(doc: Creation): Base | undefined;
export declare function workingBase(doc: Pick<Creation, "bases" | "workingBaseId">): Base | undefined;
export declare function outputHasCards(output: Output | null | undefined): boolean;
export declare function kindForCitation(kind: Operation["kind"], citation?: ContentCitation): Operation["kind"];
export declare function isBodyOnlyRevision(current: Output | null | undefined, next: Output, operation?: Pick<Operation, "kind" | "mode" | "requestedMode" | "applyIntent" | "target" | "citation">): boolean;
export declare class CreationError extends Error {
    status: number;
    constructor(status: number, message: string);
}
