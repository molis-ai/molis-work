import { type Material } from "../domain/creation.ts";
import type { CreationStore } from "../storage/creation-store.ts";
import { readCreationUrl } from "../infrastructure/creation-url-reader.ts";
export declare class CreationMaterialLibrary {
    private store;
    private reader;
    constructor(store: CreationStore, reader?: typeof readCreationUrl);
    list(workId?: string): Promise<{
        id: string;
        name: string;
        savedAt: string;
        url: string | undefined;
        format: "PDF" | "DOCX" | "TEXT" | "IMAGE" | "AUDIO" | "VIDEO" | undefined;
        kind: "WEB_TEXT" | "VIDEO_TRANSCRIPT" | "AUDIO_TRANSCRIPT" | "USER_TRANSCRIPT" | "DOCUMENT_TEXT" | "IMAGE_TEXT" | "FEED_DIRECTORY" | undefined;
        characters: number;
        excerpt: string;
        readable: boolean;
        needsOcr: boolean;
        readScope: "FULL" | "PARTIAL" | "REFERENCE_ONLY" | undefined;
        extraction: {
            extractor: string;
            coverage: {
                status: "sufficient" | "partial" | "insufficient";
                processed_pages: number;
                total_pages: number;
                issues: string[];
                truncated?: boolean | undefined;
            };
            locations: {
                text: string;
                page?: number | undefined;
                start_seconds?: number | undefined;
                end_seconds?: number | undefined;
            }[];
            duration_seconds?: number | undefined;
        } | undefined;
        status: "FAILED" | "READING" | "UNDERSTANDING" | "READY" | "NEEDS_LOGIN";
        message: string;
        added: boolean;
        uses: number;
    }[]>;
    /** One snapshot ties the picker/recovery receipt to its exact work revision. */
    forWork(workId: string): Promise<{
        work: import("../domain/creation.ts").Creation;
        materials: {
            id: string;
            name: string;
            savedAt: string;
            url: string | undefined;
            format: "PDF" | "DOCX" | "TEXT" | "IMAGE" | "AUDIO" | "VIDEO" | undefined;
            kind: "WEB_TEXT" | "VIDEO_TRANSCRIPT" | "AUDIO_TRANSCRIPT" | "USER_TRANSCRIPT" | "DOCUMENT_TEXT" | "IMAGE_TEXT" | "FEED_DIRECTORY" | undefined;
            characters: number;
            excerpt: string;
            readable: boolean;
            needsOcr: boolean;
            readScope: "FULL" | "PARTIAL" | "REFERENCE_ONLY" | undefined;
            extraction: {
                extractor: string;
                coverage: {
                    status: "sufficient" | "partial" | "insufficient";
                    processed_pages: number;
                    total_pages: number;
                    issues: string[];
                    truncated?: boolean | undefined;
                };
                locations: {
                    text: string;
                    page?: number | undefined;
                    start_seconds?: number | undefined;
                    end_seconds?: number | undefined;
                }[];
                duration_seconds?: number | undefined;
            } | undefined;
            status: "FAILED" | "READING" | "UNDERSTANDING" | "READY" | "NEEDS_LOGIN";
            message: string;
            added: boolean;
            uses: number;
        }[];
    }>;
    private summaries;
    read(id: string): Promise<import("../domain/material-library.ts").SavedMaterial>;
    collect(input: unknown): Promise<import("../domain/material-library.ts").SavedMaterial[]>;
    attach(workId: string, input: unknown): Promise<import("../domain/creation.ts").Creation>;
    importFile(name: string, bytes: Buffer): Promise<Material>;
    attachment(id: string, preview: boolean): Promise<{
        format: import("../domain/creation-material-extraction.ts").AttachmentFormat;
        html: string;
        bytes: Buffer;
        name: string;
    }>;
    startRead(id: string, input: unknown): Promise<import("../domain/material-library.ts").SavedMaterial>;
    private executeRead;
    recover(): Promise<void>;
}
